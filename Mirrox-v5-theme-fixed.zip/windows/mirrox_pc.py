#!/usr/bin/env python3
"""Mirrox for Windows (companion): pair with PIN/QR, send and receive files, show the phone screen.

Run the app:          python mirrox_pc.py
Headless receiver:    python mirrox_pc.py --headless
Send a file (CLI):    python mirrox_pc.py send 192.168.1.5 photo.jpg --code 482731 [--fp <fingerprint>]
See ../PROTOCOL.md for the wire format.
"""
import argparse
import hmac
import json
import os
import queue
import re
import secrets
import hashlib
import socket
import ssl
import struct
import sys
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import urlencode

import mirrox_cast as cast

PROTO_V = 2

PORT = 48500
SERVICE = "_mirrox._tcp.local."
MAX_HEADER = 64 * 1024
MAX_FILE = 64 * 1024 ** 3
CHUNK = 64 * 1024
MY_TYPE = "windows" if os.name == "nt" else "linux"


# ----------------------------------------------------------------------------- framing
def send_msg(sock, obj):
    data = json.dumps(obj, separators=(",", ":")).encode("utf-8")
    sock.sendall(struct.pack(">I", len(data)) + data)


def recv_exact(sock, n):
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            raise ConnectionError("connection closed")
        buf += chunk
    return bytes(buf)


def recv_msg(sock):
    (n,) = struct.unpack(">I", recv_exact(sock, 4))
    if n < 1 or n > MAX_HEADER:
        raise ConnectionError("bad header size")
    obj = json.loads(recv_exact(sock, n).decode("utf-8"))
    if not isinstance(obj, dict):
        raise ValueError("message must be an object")
    return obj


def same(a, b):
    return hmac.compare_digest(str(a).encode("utf-8"), str(b).encode("utf-8"))


def local_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


def safe_name(name):
    name = os.path.basename(str(name or "").replace("\\", "/"))
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]', "_", name).strip(" .")
    if not name:
        name = "file"
    if re.match(r"^(con|prn|aux|nul|com\d|lpt\d)(\..*)?$", name, re.I):
        name = "_" + name
    return name[:200]


def unique_path(folder, name):
    p = folder / name
    stem, suf, i = p.stem, p.suffix, 1
    while p.exists():
        p = folder / f"{stem} ({i}){suf}"
        i += 1
    return p



# ----------------------------------------------------------------------------- TLS identity
def fingerprint(der):
    """SHA-256 of a DER certificate, lowercase hex. This is what devices pin."""
    return hashlib.sha256(der).hexdigest()


def make_identity(cert_path, key_path):
    """Create a long-lived self-signed ECDSA P-256 certificate (once per device)."""
    import datetime
    from cryptography import x509
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec
    from cryptography.x509.oid import NameOID

    key = ec.generate_private_key(ec.SECP256R1())
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "Mirrox")])
    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name)
            .public_key(key.public_key()).serial_number(x509.random_serial_number())
            .not_valid_before(now - datetime.timedelta(days=1))
            .not_valid_after(now + datetime.timedelta(days=365 * 20))
            .sign(key, hashes.SHA256()))
    key_path.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.PKCS8,
                                           serialization.NoEncryption()))
    try:
        os.chmod(key_path, 0o600)
    except OSError:
        pass
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))


def server_context(cert_path, key_path):
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(str(cert_path), str(key_path))
    return ctx


def client_context():
    """No CA validation: trust is decided by comparing the certificate fingerprint (pinning)."""
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    return ctx


# ----------------------------------------------------------------------------- config
class Config:
    """Device identity + known devices, stored in ~/.mirrox/config.json."""

    def __init__(self, home=None, name=None, downloads=None):
        self.dir = Path(home or os.environ.get("MIRROX_HOME") or Path.home() / ".mirrox")
        self.dir.mkdir(parents=True, exist_ok=True)
        self.path = self.dir / "config.json"
        self.lock = threading.RLock()     # `known` is changed by server threads and the GUI thread
        data = {}
        try:
            data = json.loads(self.path.read_text("utf-8"))
        except (OSError, ValueError):
            pass
        self.id = data.get("id") or uuid.uuid4().hex
        self.name = name or data.get("name") or socket.gethostname()
        self.downloads = Path(downloads or data.get("downloads") or Path.home() / "Downloads" / "Mirrox")
        # known[peer_id] = {name,type,host,port,last, issued (token we gave them), token (token they gave us)}
        self.known = data.get("known", {})
        # v1 tokens were sent in clear text: revoke them all once (devices must pair again).
        if data.get("proto") != PROTO_V:
            for info in self.known.values():
                info.pop("token", None)
                info.pop("issued", None)
        self.cert_path, self.key_path = self.dir / "cert.pem", self.dir / "key.pem"
        if not (self.cert_path.exists() and self.key_path.exists()):
            make_identity(self.cert_path, self.key_path)
        from cryptography import x509
        from cryptography.hazmat.primitives import serialization
        der = x509.load_pem_x509_certificate(self.cert_path.read_bytes()).public_bytes(serialization.Encoding.DER)
        self.fp = fingerprint(der)
        self.save()

    def save(self):
        with self.lock:
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps({"proto": PROTO_V, "id": self.id, "name": self.name, "downloads": str(self.downloads), "known": self.known}, indent=1), "utf-8")
            os.replace(tmp, self.path)

    def remember(self, pid, **kw):
        with self.lock:
            self.known.setdefault(pid, {}).update(kw)
            self.save()

    def forget(self, pid):
        with self.lock:
            self.known.pop(pid, None)
            self.save()

    def drop_token(self, pid):
        """The other device no longer accepts our token (it forgot us): ask for a PIN next time."""
        with self.lock:
            if pid in self.known and self.known[pid].pop("token", None) is not None:
                self.save()


# ----------------------------------------------------------------------------- server
class Server:
    def __init__(self, cfg, port=PORT, on_event=None):
        self.cfg = cfg
        self.on_event = on_event or (lambda *a: None)
        self.ctx = server_context(cfg.cert_path, cfg.key_path)
        self.code = self._new_code()
        self.fails = 0
        self.running = True
        self.accept_cast = True          # False: no window to show a screen (headless)
        self.decoder_factory = None      # tests can inject a decoder
        self._cast_lock = threading.Lock()
        self._casting = False
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.sock.bind(("", port))
        except OSError:
            self.sock.bind(("", 0))
        self.sock.listen(8)
        self.port = self.sock.getsockname()[1]

    @staticmethod
    def _new_code():
        return f"{secrets.randbelow(1000000):06d}"

    def rotate(self):
        self.code, self.fails = self._new_code(), 0
        self.on_event("code", self.code)

    def start(self):
        threading.Thread(target=self._accept, daemon=True).start()
        return self

    def stop(self):
        self.running = False
        try:
            self.sock.close()
        except OSError:
            pass

    def _accept(self):
        while self.running:
            try:
                conn, addr = self.sock.accept()
            except OSError:
                break
            threading.Thread(target=self._handle, args=(conn, addr), daemon=True).start()

    def _handle(self, raw, addr):
        conn = raw
        raw.settimeout(30)
        try:
            conn = self.ctx.wrap_socket(raw, server_side=True)
            peer = self._auth(conn, recv_msg(conn), addr)
            if not peer:
                return
            while True:
                msg = recv_msg(conn)
                t = msg.get("t")
                if t == "file":
                    self._receive(conn, msg, peer)
                elif t == "cast_start":
                    self._cast(conn, msg, peer)
                    break                      # a cast owns the connection until it ends
                elif t == "bye":
                    break
                else:
                    send_msg(conn, {"t": "err", "msg": "unsupported"})
        except (OSError, ValueError):
            pass
        finally:
            for c in (conn, raw):
                try:
                    c.close()
                except OSError:
                    pass

    def _auth(self, conn, hello, addr):
        pid, token, code = hello.get("id"), hello.get("token"), hello.get("code")
        if hello.get("t") != "hello" or hello.get("v") != PROTO_V or not isinstance(pid, str) or not pid or len(pid) > 64:
            send_msg(conn, {"t": "err", "msg": "bad_hello"})
            return None
        name = str(hello.get("name") or "Unknown")[:64]
        typ = hello.get("type") if hello.get("type") in ("android", "windows", "linux", "ios", "mac") else "unknown"
        issued = self.cfg.known.get(pid, {}).get("issued")
        new_token = None
        if isinstance(token, str) and issued and same(token, issued):
            ok = True
        elif isinstance(code, str) and code:
            ok = same(code, self.code)
            if ok:
                new_token = secrets.token_hex(16)
                self.cfg.remember(pid, issued=new_token)
                self.rotate()
            else:
                self.fails += 1
                if self.fails >= 5:
                    self.rotate()
        else:
            ok = False
        if not ok:
            send_msg(conn, {"t": "err", "msg": "auth"})
            return None
        self.cfg.remember(pid, name=name, type=typ, host=addr[0], last=time.time())
        reply = {"t": "ok", "v": PROTO_V, "id": self.cfg.id, "name": self.cfg.name, "type": MY_TYPE}
        if new_token:
            reply["token"] = new_token
        send_msg(conn, reply)
        self.on_event("peer", pid, name)
        return {"id": pid, "name": name}

    def _receive(self, conn, msg, peer):
        name, size = safe_name(msg.get("name")), msg.get("size")
        if not isinstance(size, int) or isinstance(size, bool) or size < 0 or size > MAX_FILE:
            send_msg(conn, {"t": "err", "msg": "bad_size"})
            raise ConnectionError("bad size")
        self.cfg.downloads.mkdir(parents=True, exist_ok=True)
        dest = unique_path(self.cfg.downloads, name)
        tmp = dest.with_name(dest.name + ".part")
        done = 0
        try:
            with open(tmp, "wb") as f:
                while done < size:
                    chunk = conn.recv(min(CHUNK, size - done))
                    if not chunk:
                        raise ConnectionError("cancelled")
                    f.write(chunk)
                    done += len(chunk)
                    self.on_event("progress", name, done, size, "in")
            os.replace(tmp, dest)
        except BaseException:
            try:
                tmp.unlink()
            except OSError:
                pass
            self.on_event("failed", name)
            raise
        send_msg(conn, {"t": "file_ok", "name": dest.name})
        self.on_event("received", str(dest), size, peer["name"])

    def _cast(self, conn, msg, peer):
        """Phone -> PC screen cast: answer `cast_ok`, then read video packets until the cast ends."""
        info, bad = cast.parse_start(msg)
        if bad:
            send_msg(conn, {"t": "err", "msg": bad})
            return
        if not self.accept_cast:
            send_msg(conn, {"t": "err", "msg": "no_display"})
            return
        with self._cast_lock:
            if self._casting:
                send_msg(conn, {"t": "err", "msg": "cast_busy"})
                return
            self._casting = True
        sess = None
        try:
            try:
                sess = cast.CastSession(info, peer["name"], self.decoder_factory)
            except cast.NoDecoder:
                send_msg(conn, {"t": "err", "msg": "no_decoder"})
                return
            send_msg(conn, {"t": "cast_ok"})
            conn.settimeout(15)               # the phone sends a keep-alive every 2 s
            self.on_event("cast", sess)
            sess.run(conn)
        finally:
            with self._cast_lock:
                self._casting = False
            if sess is not None:
                sess.finish()
                self.on_event("cast_end", sess)


# ----------------------------------------------------------------------------- client
class ClientError(Exception):
    pass


def connect(cfg, host, port=PORT, peer_id=None, code=None, timeout=10, fp=None):
    """Open a TLS session. Returns (socket, hello_reply). Stores any token we are given.

    The server certificate must match a pinned fingerprint: `fp` (from a QR code) or the one saved
    for `peer_id`. With neither (first PIN pairing) the fingerprint is learned and pinned on success.
    """
    known = cfg.known.get(peer_id, {}) if peer_id else {}
    pinned = (fp or known.get("fp") or "").lower() or None
    raw = socket.create_connection((host, port), timeout=timeout)
    s = raw
    try:
        s = client_context().wrap_socket(raw, server_hostname=None)
        seen = fingerprint(s.getpeercert(binary_form=True))
        if pinned and not same(seen, pinned):
            raise ClientError("cert_changed")
        hello = {"t": "hello", "v": PROTO_V, "id": cfg.id, "name": cfg.name, "type": MY_TYPE}
        tok = known.get("token") if pinned else None   # never send a token to an unpinned server
        if tok:
            hello["token"] = tok
        if code:
            hello["code"] = str(code)
        if "token" not in hello and "code" not in hello:
            raise ClientError("pin_required")
        send_msg(s, hello)
        reply = recv_msg(s)
        if reply.get("t") != "ok":
            if reply.get("msg") == "auth" and tok and not code and peer_id:
                cfg.drop_token(peer_id)       # stale token: the next attempt will ask for the PIN
                raise ClientError("token_rejected")
            raise ClientError(reply.get("msg", "failed"))
        s.settimeout(60)                      # connect() used 10 s; big files on slow Wi-Fi need more patience
        rid = reply.get("id")
        if isinstance(rid, str):
            info = {"name": reply.get("name"), "type": reply.get("type"), "host": host, "port": port,
                    "last": time.time(), "fp": seen}
            if reply.get("token"):
                info["token"] = reply["token"]
            cfg.remember(rid, **info)
        return s, reply
    except BaseException:
        for c in (s, raw):
            try:
                c.close()
            except OSError:
                pass
        raise


def send_file(cfg, host, port, path, peer_id=None, code=None, progress=None, cancelled=None, fp=None):
    s, _ = connect(cfg, host, port, peer_id, code, fp=fp)
    try:
        size = os.path.getsize(path)
        send_msg(s, {"t": "file", "name": os.path.basename(path), "size": size})
        done = 0
        with open(path, "rb") as f:
            while True:
                chunk = f.read(CHUNK)
                if not chunk:
                    break
                if cancelled and cancelled():
                    raise ClientError("cancelled")
                s.sendall(chunk)
                done += len(chunk)
                if progress:
                    progress(done, size)
        s.settimeout(30)
        resp = recv_msg(s)
        if resp.get("t") != "file_ok":
            raise ClientError(resp.get("msg", "failed"))
        send_msg(s, {"t": "bye"})
        return resp.get("name")
    finally:
        s.close()


def qr_payload(cfg, server):
    q = {"host": local_ip(), "port": server.port, "code": server.code, "id": cfg.id, "name": cfg.name, "fp": cfg.fp, "v": PROTO_V}
    return "mirrox://pair?" + urlencode(q)


# ----------------------------------------------------------------------------- discovery
class Discovery:
    """Advertise this PC and list other Mirrox devices (needs `pip install zeroconf`)."""

    def __init__(self, cfg, port, on_change=None):
        from zeroconf import ServiceBrowser, ServiceInfo, Zeroconf
        self.cfg, self.on_change, self.peers = cfg, on_change or (lambda: None), {}
        self.zc = Zeroconf()
        label = cfg.name.replace(".", "-")[:60]
        self.info = ServiceInfo(
            SERVICE, f"{label}.{SERVICE}", addresses=[socket.inet_aton(local_ip())], port=port,
            properties={"id": cfg.id, "type": MY_TYPE}, server=f"mirrox-{cfg.id[:8]}.local.")
        self.zc.register_service(self.info)
        self.browser = ServiceBrowser(self.zc, SERVICE, handlers=[self._on_service])

    def _on_service(self, zeroconf, service_type, name, state_change):
        from zeroconf import ServiceStateChange
        if state_change is ServiceStateChange.Removed:
            if self.peers.pop(name, None):
                self.on_change()
        else:
            threading.Thread(target=self._resolve, args=(zeroconf, service_type, name), daemon=True).start()

    def _resolve(self, zeroconf, service_type, name):
        info = zeroconf.get_service_info(service_type, name, timeout=3000)
        if not info:
            return
        props = {k.decode(): (v or b"").decode() for k, v in info.properties.items()}
        addrs = info.parsed_addresses()
        v4 = [a for a in addrs if ":" not in a]
        if not props.get("id") or props["id"] == self.cfg.id or not (v4 or addrs):
            return
        self.peers[name] = {"id": props["id"], "type": props.get("type", "unknown"), "host": (v4 or addrs)[0],
                            "port": info.port, "name": name[: -len(SERVICE) - 1]}
        self.on_change()

    def close(self):
        try:
            self.zc.unregister_service(self.info)
            self.zc.close()
        except Exception:
            pass


# ----------------------------------------------------------------------------- GUI
def run_gui(cfg, server, disc):
    import tkinter as tk
    from tkinter import filedialog, messagebox, simpledialog, ttk

    events = queue.Queue()
    server.on_event = lambda *a: events.put(a)
    if disc:
        disc.on_change = lambda: events.put(("peers",))

    root = tk.Tk()
    root.title("Mirrox")
    root.geometry("380x600")
    root.configure(bg="white")
    font = "Segoe UI"
    tk.Label(root, text="Mirrox", font=(font, 18), bg="white").pack(anchor="w", padx=16, pady=(16, 0))
    status = tk.Label(root, text="Ready to receive", font=(font, 11), fg="#5F6B7A", bg="white")
    status.pack(anchor="w", padx=16)
    qr_label = tk.Label(root, bg="white")
    qr_label.pack(pady=(14, 4))
    code_label = tk.Label(root, font=(font, 26), bg="white")
    code_label.pack()
    tk.Label(root, text="Scan this QR code or enter the code on another Mirrox device.", font=(font, 10),
             fg="#5F6B7A", bg="white", wraplength=320).pack(pady=(4, 12))
    ttk.Separator(root).pack(fill="x", padx=16)
    tk.Label(root, text="Nearby Devices", font=(font, 10), fg="#5F6B7A", bg="white").pack(anchor="w", padx=16, pady=(10, 4))
    lst = tk.Listbox(root, height=6, relief="flat", highlightthickness=1, highlightbackground="#E3E6EA", font=(font, 11))
    lst.pack(fill="x", padx=16)
    peers_view = []

    def refresh_qr():
        code_label.config(text=f"{server.code[:3]} {server.code[3:]}")
        try:
            import qrcode
            from PIL import ImageTk
            img = qrcode.make(qr_payload(cfg, server)).convert("RGB").resize((190, 190))
            photo = ImageTk.PhotoImage(img)
            qr_label.config(image=photo)
            qr_label.image = photo
        except ImportError:
            qr_label.config(text="(install qrcode[pil] to show a QR code)", fg="#5F6B7A", font=(font, 9))

    def refresh_peers():
        peers_view[:] = list(disc.peers.values()) if disc else []
        lst.delete(0, "end")
        for p in peers_view:
            lst.insert("end", f"{p['name']}   ({p['type']})")

    def do_send():
        sel = lst.curselection()
        if not sel:
            messagebox.showinfo("Send File", "Select a device first.")
            return
        p = peers_view[sel[0]]
        path = filedialog.askopenfilename(title="Select file")
        if not path:
            return
        code = None
        if not cfg.known.get(p["id"], {}).get("token"):
            code = simpledialog.askstring("Enter PIN", f"Enter the 6-digit code shown on {p['name']}:")
            if not code:
                return

        def work():
            try:
                send_file(cfg, p["host"], p["port"], path, p["id"], code,
                          progress=lambda d, t: events.put(("progress", os.path.basename(path), d, t, "out")))
                events.put(("sent", os.path.basename(path), p["name"]))
            except ClientError as e:
                events.put(("cert_changed", p) if str(e) == "cert_changed" else ("error", str(e)))
            except (OSError, ValueError) as e:
                events.put(("error", str(e)))
        threading.Thread(target=work, daemon=True).start()

    nice = {
        "auth": "Wrong PIN. Check the code on the other device.",
        "token_rejected": "That device no longer trusts this PC. Press Send again and enter the PIN shown on it.",
        "pin_required": "Enter the PIN shown on the other device.",
        "cert_changed": "The device's security identity changed.",
    }

    row = tk.Frame(root, bg="white")
    row.pack(fill="x", padx=16, pady=12)
    ttk.Button(row, text="Send File…", command=do_send).pack(side="left")
    ttk.Button(row, text="Open Received Folder", command=lambda: (cfg.downloads.mkdir(parents=True, exist_ok=True), os.startfile(str(cfg.downloads)) if os.name == "nt" else None)).pack(side="left", padx=8)

    def open_viewer(sess):
        """A window that shows the phone's screen. Closing it ends the cast."""
        from PIL import ImageTk
        win = tk.Toplevel(root)
        win.configure(bg="black")
        sw, sh = sess.size
        k = min(460 / sw, 860 / sh, 1.0)
        win.geometry(f"{max(int(sw * k), 200)}x{max(int(sh * k), 200)}")
        canvas = tk.Canvas(win, bg="black", highlightthickness=0)
        canvas.pack(fill="both", expand=True)
        item = canvas.create_image(0, 0, anchor="center")
        note = canvas.create_text(0, 0, fill="white", font=(font, 14), text="")
        st = {"ver": -1, "photo": None, "title": "", "full": False}

        def fit():
            cw, ch = max(canvas.winfo_width(), 2), max(canvas.winfo_height(), 2)
            w, h = sess.size
            s = min(cw / w, ch / h)
            return max(int(w * s), 2), max(int(h * s), 2)

        def close():
            sess.stop()
            win.destroy()

        def fullscreen(_e=None):
            st["full"] = not st["full"]
            win.attributes("-fullscreen", st["full"])

        def tick():
            if not win.winfo_exists():
                return
            cw, ch = max(canvas.winfo_width(), 2), max(canvas.winfo_height(), 2)
            size = fit()
            sess.view_size = size
            got = sess.take(st["ver"])
            if got:
                img, st["ver"] = got
                if img.size != size:
                    img = img.resize(size)
                st["photo"] = ImageTk.PhotoImage(img)
                canvas.itemconfig(item, image=st["photo"])
            canvas.coords(item, cw // 2, ch // 2)
            canvas.coords(note, cw // 2, ch // 2)
            ended = sess.finished.is_set()
            canvas.itemconfig(note, text="Casting ended" if ended else ("Paused" if sess.paused else ""))
            title = f"{sess.peer}  -  {sess.size[0]}x{sess.size[1]}  {sess.fps_now():.0f} fps" + ("  (ended)" if ended else "")
            if title != st["title"]:
                st["title"] = title
                win.title(title)
            win.after(15 if not ended else 500, tick)

        win.protocol("WM_DELETE_WINDOW", close)
        win.bind("<F11>", fullscreen)
        win.bind("<Double-Button-1>", fullscreen)
        win.bind("<Escape>", lambda _e: win.attributes("-fullscreen", False) or st.update(full=False))
        tick()

    def poll():
        try:
            while True:
                ev = events.get_nowait()
                k = ev[0]
                if k == "cast":
                    status.config(text="Showing a screen")
                    try:
                        open_viewer(ev[1])
                    except Exception as e:           # no window means nobody could stop the cast
                        ev[1].stop()
                        status.config(text="Ready to receive")
                        messagebox.showerror("Mirrox", f"Could not open the screen window: {e}")
                elif k == "cast_end":
                    status.config(text="Ready to receive")
                elif k == "code":
                    refresh_qr()
                elif k == "peers":
                    refresh_peers()
                elif k == "progress":
                    _, name, d, t, way = ev
                    status.config(text=f"{'Receiving' if way == 'in' else 'Sending'} {name}  {100 * d // max(t, 1)}%")
                elif k in ("received", "sent"):
                    status.config(text="Ready to receive")
                    messagebox.showinfo("Mirrox", f"{'Received' if k == 'received' else 'Sent'}: {os.path.basename(ev[1])}")
                elif k == "error":
                    status.config(text="Ready to receive")
                    messagebox.showerror("Mirrox", f"Failed: {nice.get(ev[1], ev[1])}")
                elif k == "cert_changed":
                    status.config(text="Ready to receive")
                    if messagebox.askyesno("Mirrox", f"The security identity of {ev[1]['name']} has changed.\n\n"
                                           "This happens after reinstalling Mirrox, but it could also mean someone "
                                           "is impersonating that device. Forget it and pair again with a new PIN?"):
                        cfg.forget(ev[1]["id"])
                elif k == "failed":
                    status.config(text="Ready to receive")
        except queue.Empty:
            pass
        except Exception as e:                       # keep the window alive whatever one event does
            print("event error:", e, file=sys.stderr)
        root.after(50, poll)

    refresh_qr()
    refresh_peers()
    poll()
    root.mainloop()


# ----------------------------------------------------------------------------- main
def main(argv=None):
    ap = argparse.ArgumentParser(description="Mirrox for Windows")
    ap.add_argument("--headless", action="store_true", help="no window, just receive files")
    ap.add_argument("--name"), ap.add_argument("--downloads"), ap.add_argument("--home")
    ap.add_argument("--port", type=int, default=PORT)
    sub = ap.add_subparsers(dest="cmd")
    sp = sub.add_parser("send", help="send a file to a device")
    sp.add_argument("host"), sp.add_argument("file")
    sp.add_argument("--port", dest="sport", type=int, default=PORT)
    sp.add_argument("--code"), sp.add_argument("--id")
    sp.add_argument("--fp", help="expected certificate fingerprint (from the QR code)")
    fp_ = sub.add_parser("forget", help="forget a paired device")
    fp_.add_argument("id")
    a = ap.parse_args(argv)
    cfg = Config(a.home, a.name, a.downloads)

    if a.cmd == "send":
        try:
            name = send_file(cfg, a.host, a.sport, a.file, a.id, a.code, fp=a.fp,
                             progress=lambda d, t: print(f"\r{100 * d // max(t, 1)}%", end="", flush=True))
            print(f"\nSent as {name}")
        except (OSError, ClientError) as e:
            print(f"\nFailed: {e}", file=sys.stderr)
            return 1
        return 0

    if a.cmd == "forget":
        cfg.forget(a.id)
        print("Forgotten.")
        return 0

    server = Server(cfg, a.port).start()
    disc = None
    try:
        disc = Discovery(cfg, server.port)
    except ImportError:
        print("zeroconf not installed: device discovery disabled (pip install zeroconf)", file=sys.stderr)
    except OSError as e:
        print(f"discovery unavailable: {e}", file=sys.stderr)
    print(f"{cfg.name} listening on {local_ip()}:{server.port}  PIN {server.code}  fingerprint {cfg.fp}")
    try:
        if a.headless:
            server.accept_cast = False
            server.on_event = lambda *e: print(*e, flush=True)
            while True:
                time.sleep(3600)
        else:
            run_gui(cfg, server, disc)
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()
        if disc:
            disc.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())
