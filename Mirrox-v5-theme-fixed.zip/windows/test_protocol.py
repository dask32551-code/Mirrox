import hashlib
import os
import socket
import struct
import tempfile
import threading
import time
import unittest
from pathlib import Path

import mirrox_pc as m


def make_peer(tmp, name):
    home = Path(tmp) / name
    return m.Config(str(home), name, str(home / "Received"))


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.events = []
        self.rx = make_peer(self.tmp.name, "RX")
        self.tx = make_peer(self.tmp.name, "TX")
        self.server = m.Server(self.rx, 0, lambda *a: self.events.append(a)).start()
        self.port = self.server.port
        self.src = Path(self.tmp.name) / "photo.bin"
        self.src.write_bytes(os.urandom(3 * 1024 * 1024 + 123))

    def tearDown(self):
        self.server.stop()
        self.tmp.cleanup()

    def sha(self, p):
        return hashlib.sha256(Path(p).read_bytes()).hexdigest()

    def test_pair_then_token_reuse_and_pin_rotates(self):
        old = self.server.code
        name = m.send_file(self.tx, "127.0.0.1", self.port, self.src, code=old)
        self.assertEqual(self.sha(self.rx.downloads / name), self.sha(self.src))
        self.assertNotEqual(self.server.code, old, "PIN must rotate after pairing")
        self.assertTrue(self.tx.known[self.rx.id]["token"])
        # second send: token only, no PIN
        name2 = m.send_file(self.tx, "127.0.0.1", self.port, self.src, peer_id=self.rx.id)
        self.assertNotEqual(name, name2, "clashing name must be made unique")
        self.assertEqual(self.sha(self.rx.downloads / name2), self.sha(self.src))

    def test_old_pin_rejected_after_rotation(self):
        old = self.server.code
        m.send_file(self.tx, "127.0.0.1", self.port, self.src, code=old)
        other = make_peer(self.tmp.name, "OTHER")
        with self.assertRaises(m.ClientError):
            m.send_file(other, "127.0.0.1", self.port, self.src, code=old)

    def test_wrong_pin_and_no_credentials(self):
        with self.assertRaises(m.ClientError) as e:
            m.send_file(self.tx, "127.0.0.1", self.port, self.src, code="000000" if self.server.code != "000000" else "111111")
        self.assertEqual(str(e.exception), "auth")
        with self.assertRaises(m.ClientError) as e:
            m.send_file(self.tx, "127.0.0.1", self.port, self.src)
        self.assertEqual(str(e.exception), "pin_required")
        self.assertFalse(self.rx.downloads.exists() and any(self.rx.downloads.iterdir()))

    def test_five_failures_rotate_pin(self):
        good = self.server.code
        for _ in range(5):
            try:
                m.connect(self.tx, "127.0.0.1", self.port, code="x" + good)
            except m.ClientError:
                pass
        self.assertNotEqual(self.server.code, good)

    def test_stale_token_is_dropped_and_pin_works_again(self):
        m.send_file(self.tx, "127.0.0.1", self.port, self.src, code=self.server.code)
        self.assertTrue(self.tx.known[self.rx.id]["token"])
        self.rx.forget(self.tx.id)                       # the receiver forgets us: our token is now stale
        with self.assertRaises(m.ClientError) as e:
            m.send_file(self.tx, "127.0.0.1", self.port, self.src, peer_id=self.rx.id)
        self.assertEqual(str(e.exception), "token_rejected")
        self.assertNotIn("token", self.tx.known[self.rx.id], "stale token must be dropped")
        self.assertTrue(self.tx.known[self.rx.id].get("fp"), "pinned fingerprint is kept")
        # next attempt needs (and accepts) a fresh PIN
        with self.assertRaises(m.ClientError) as e:
            m.send_file(self.tx, "127.0.0.1", self.port, self.src, peer_id=self.rx.id)
        self.assertEqual(str(e.exception), "pin_required")
        name = m.send_file(self.tx, "127.0.0.1", self.port, self.src, peer_id=self.rx.id, code=self.server.code)
        self.assertEqual(self.sha(self.rx.downloads / name), self.sha(self.src))

    def test_config_survives_concurrent_updates(self):
        errors = []

        def hammer(n):
            try:
                for i in range(150):
                    self.rx.remember(f"dev-{n}-{i}", name="x" * 20, last=time.time())
            except Exception as e:                      # e.g. "dictionary changed size during iteration"
                errors.append(e)

        ts = [threading.Thread(target=hammer, args=(n,)) for n in range(6)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(errors, [])
        self.assertEqual(len([k for k in self.rx.known if k.startswith("dev-")]), 900)

    def test_path_traversal_name_is_sanitised(self):
        s, _ = m.connect(self.tx, "127.0.0.1", self.port, code=self.server.code)
        m.send_msg(s, {"t": "file", "name": "..\\..\\evil/../../x.txt", "size": 3})
        s.sendall(b"abc")
        self.assertEqual(m.recv_msg(s)["t"], "file_ok")
        s.close()
        files = [p.name for p in self.rx.downloads.iterdir()]
        self.assertEqual(files, ["x.txt"])
        self.assertFalse((Path(self.tmp.name) / "x.txt").exists())

    def test_reserved_and_empty_names(self):
        self.assertEqual(m.safe_name("CON.txt"), "_CON.txt")
        self.assertEqual(m.safe_name("..."), "file")
        self.assertEqual(m.safe_name('a<b>:"c".txt'), "a_b___c_.txt")

    def test_cancel_removes_partial_file(self):
        calls = {"n": 0}

        def cancelled():
            calls["n"] += 1
            return calls["n"] > 5

        with self.assertRaises(m.ClientError):
            m.send_file(self.tx, "127.0.0.1", self.port, self.src, code=self.server.code, cancelled=cancelled)
        time.sleep(0.5)
        leftovers = list(self.rx.downloads.iterdir()) if self.rx.downloads.exists() else []
        self.assertEqual(leftovers, [])

    def test_oversize_header_and_bad_size_rejected(self):
        s, _ = m.connect(self.tx, "127.0.0.1", self.port, code=self.server.code)
        s.sendall(struct.pack(">I", 10_000_000))
        s.settimeout(3)
        self.assertEqual(s.recv(10), b"")  # server closed
        s.close()
        s, _ = m.connect(self.tx, "127.0.0.1", self.port, code=self.server.code)
        m.send_msg(s, {"t": "file", "name": "a", "size": -5})
        self.assertEqual(m.recv_msg(s)["t"], "err")
        s.close()
        s, _ = m.connect(self.tx, "127.0.0.1", self.port, code=self.server.code)
        m.send_msg(s, {"t": "file", "name": "a", "size": True})
        self.assertEqual(m.recv_msg(s)["t"], "err")
        s.close()

    def test_empty_file_and_unknown_message(self):
        e = Path(self.tmp.name) / "empty.txt"
        e.write_bytes(b"")
        name = m.send_file(self.tx, "127.0.0.1", self.port, e, code=self.server.code)
        self.assertEqual((self.rx.downloads / name).read_bytes(), b"")
        s, _ = m.connect(self.tx, "127.0.0.1", self.port, peer_id=self.rx.id)
        m.send_msg(s, {"t": "bogus"})
        self.assertEqual(m.recv_msg(s), {"t": "err", "msg": "unsupported"})
        s.close()

    def test_qr_payload_roundtrip(self):
        from urllib.parse import parse_qs, urlparse
        u = urlparse(m.qr_payload(self.rx, self.server))
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        self.assertEqual((u.scheme, u.netloc), ("mirrox", "pair"))
        self.assertEqual(q["code"], self.server.code)
        self.assertEqual(int(q["port"]), self.port)
        self.assertEqual(q["id"], self.rx.id)
        self.assertEqual(q["fp"], self.rx.fp)
        self.assertEqual(q["v"], "2")

    # ---- TLS ----
    def test_traffic_is_encrypted_tls12_or_newer(self):
        s, _ = m.connect(self.tx, "127.0.0.1", self.port, code=self.server.code)
        self.assertIn(s.version(), ("TLSv1.2", "TLSv1.3"))
        s.close()

    def test_plaintext_client_is_rejected(self):
        s = socket.create_connection(("127.0.0.1", self.port))
        s.settimeout(3)
        m.send_msg(s, {"t": "hello", "v": 2, "id": "x", "code": self.server.code})
        try:
            data = s.recv(100)
        except OSError:
            data = b""
        self.assertNotIn(b"ok", data)
        s.close()
        self.assertFalse(self.tx.known)  # nothing paired

    def test_first_pairing_pins_fingerprint(self):
        m.send_file(self.tx, "127.0.0.1", self.port, self.src, code=self.server.code)
        self.assertEqual(self.tx.known[self.rx.id]["fp"], self.rx.fp)

    def test_qr_fingerprint_must_match(self):
        with self.assertRaises(m.ClientError) as e:
            m.send_file(self.tx, "127.0.0.1", self.port, self.src, code=self.server.code, fp="00" * 32)
        self.assertEqual(str(e.exception), "cert_changed")
        self.assertFalse(self.tx.known)  # PIN was never sent to the wrong server
        m.send_file(self.tx, "127.0.0.1", self.port, self.src, code=self.server.code, fp=self.rx.fp)

    def test_impostor_with_other_certificate_is_detected(self):
        m.send_file(self.tx, "127.0.0.1", self.port, self.src, code=self.server.code)
        impostor = make_peer(self.tmp.name, "EVIL")
        evil = m.Server(impostor, 0).start()
        try:
            # same address book entry, but the certificate is different: the token must not be sent
            self.tx.known[self.rx.id]["port"] = evil.port
            with self.assertRaises(m.ClientError) as e:
                m.send_file(self.tx, "127.0.0.1", evil.port, self.src, peer_id=self.rx.id)
            self.assertEqual(str(e.exception), "cert_changed")
            self.assertFalse(impostor.known, "impostor must not learn anything about us")
            # even a PIN pairing attempt on a known device is refused until the user forgets it
            with self.assertRaises(m.ClientError):
                m.send_file(self.tx, "127.0.0.1", evil.port, self.src, peer_id=self.rx.id, code=evil.code)
        finally:
            evil.stop()
        self.tx.forget(self.rx.id)
        self.assertNotIn(self.rx.id, self.tx.known)

    def test_legacy_tokens_without_fingerprint_are_revoked(self):
        home = Path(self.tmp.name) / "OLD"
        home.mkdir()
        import json
        (home / "config.json").write_text(json.dumps({"id": "a" * 32, "known": {
            "peer1": {"name": "Old", "token": "t", "issued": "i"}}}))
        cfg = m.Config(str(home), "OLD", str(home / "R"))
        self.assertNotIn("token", cfg.known["peer1"])
        self.assertNotIn("issued", cfg.known["peer1"])

    def test_identity_and_issued_tokens_survive_restart(self):
        m.send_file(self.tx, "127.0.0.1", self.port, self.src, code=self.server.code)
        again = m.Config(str(Path(self.tmp.name) / "RX"), "RX", None)
        self.assertEqual(again.fp, self.rx.fp)
        self.assertTrue(again.known[self.tx.id]["issued"], "tokens we issued must not be lost on restart")
        tx2 = m.Config(str(Path(self.tmp.name) / "TX"), "TX", None)
        self.assertTrue(tx2.known[self.rx.id]["token"])
        self.assertEqual(tx2.known[self.rx.id]["fp"], self.rx.fp)


class DiscoveryTest(unittest.TestCase):
    def test_two_devices_see_each_other(self):
        try:
            import zeroconf  # noqa: F401
        except ImportError:
            self.skipTest("zeroconf not installed")
        tmp = tempfile.TemporaryDirectory()
        a, b = make_peer(tmp.name, "Alpha"), make_peer(tmp.name, "Beta")
        sa, sb = m.Server(a, 0).start(), m.Server(b, 0).start()
        try:
            da, db = m.Discovery(a, sa.port), m.Discovery(b, sb.port)
        except OSError as e:
            self.skipTest(f"no multicast in this sandbox: {e}")
        try:
            end = time.time() + 15
            while time.time() < end and not (da.peers and db.peers):
                time.sleep(0.3)
            if not (da.peers and db.peers):
                self.skipTest("multicast not delivered in this sandbox")
            self.assertEqual(list(da.peers.values())[0]["id"], b.id)
            self.assertEqual(list(db.peers.values())[0]["port"], sa.port)
        finally:
            da.close(), db.close(), sa.stop(), sb.stop(), tmp.cleanup()


if __name__ == "__main__":
    unittest.main()
