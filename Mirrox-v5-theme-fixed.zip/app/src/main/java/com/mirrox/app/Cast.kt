package com.mirrox.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import androidx.annotation.RequiresApi
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.io.DataOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.roundToInt

/*
 * Screen casting (phone -> PC). Wire format: PROTOCOL.md, "Screen cast".
 *
 *   MediaProjection -> VirtualDisplay -> MediaCodec (H.264, Surface input) -> packets -> TLS socket
 *
 * Everything runs inside CastService (a foreground service of type mediaProjection), so casting keeps going
 * when the app is in the background. The UI only observes [Cast].
 */

enum class CastPhase { IDLE, CONNECTING, LIVE, FAILED }

/** Cast state that the UI observes, plus the few values the service and the UI share. */
object Cast {
    const val CP_CONFIG = 1   // u16 width, u16 height, SPS+PPS (Annex-B)
    const val CP_KEY = 2
    const val CP_DELTA = 3
    const val CP_PAUSE = 4
    const val CP_RESUME = 5
    const val CP_END = 6
    const val CP_PING = 7
    const val CP_AUDIO = 8    // raw PCM, 48000 Hz, 2 channels, 16-bit little-endian, about 20 ms per packet

    /** Set by the app UI; the service uses it to open the secure connection. */
    @Volatile var net: Net? = null

    var phase by mutableStateOf(CastPhase.IDLE)
    var error by mutableStateOf<String?>(null)
    var paused by mutableStateOf(false)
    var peer by mutableStateOf<Peer?>(null)
    var stats by mutableStateOf("")

    /** The cast we are currently showing (another device is casting to this phone), if any. */
    var viewer by mutableStateOf<ViewerSession?>(null)
        private set

    @Synchronized fun offerViewer(v: ViewerSession): Boolean {
        if (viewer != null || phase == CastPhase.LIVE || phase == CastPhase.CONNECTING) return false
        viewer = v
        return true
    }

    @Synchronized fun viewerEnded(v: ViewerSession) { if (viewer === v) viewer = null }

    fun begin(p: Peer) { peer = p; paused = false; error = null; stats = ""; phase = CastPhase.CONNECTING }
    fun fail(msg: String) { error = msg; stats = ""; phase = CastPhase.FAILED }
    fun reset() { error = null; stats = ""; paused = false; phase = CastPhase.IDLE }

    /** Short side of the video in pixels for a "Video Quality" setting. */
    fun targetFor(quality: String?) = when {
        quality == null -> 720
        quality.startsWith("High") -> 1080
        quality.startsWith("Medium") -> 720
        quality.startsWith("Low") -> 480
        else -> 720   // Auto
    }

    fun fpsFor(setting: String?) = if (setting != null && setting.startsWith("60")) 60 else 30
}

class CastService : Service() {
    @Volatile private var current: CastRun? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            val r = current
            if (r != null) r.requestStop() else stopSelf()
            return START_NOT_STICKY
        }
        if (current != null) return START_NOT_STICKY

        val peer = Peer(
            intent.getStringExtra("id") ?: "", intent.getStringExtra("name") ?: "Device",
            intent.getStringExtra("type") ?: "unknown", intent.getStringExtra("host") ?: "",
            intent.getIntExtra("port", Proto.PORT)
        )
        val data = projectionData(intent)
        if (data == null || peer.host.isEmpty()) {
            Cast.fail("Could not start screen capture.")
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            startAsForeground(peer.name)
        } catch (e: Exception) {
            Cast.fail("Android did not allow Mirrox to start screen capture.")
            stopSelf()
            return START_NOT_STICKY
        }

        val cast = CastRun(applicationContext, peer, intent.getIntExtra("code", 0), data,
            intent.getIntExtra("target", 720), intent.getIntExtra("fps", 30))
        current = cast
        Thread({
            try { cast.execute() } finally {
                current = null
                ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }, "mirrox-cast").start()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        current?.requestStop()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun projectionData(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java) else i.getParcelableExtra("data")

    private fun startAsForeground(peerName: String) {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CHANNEL, "Screen casting", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stop = PendingIntent.getService(this, 1, Intent(this, CastService::class.java).setAction(ACTION_STOP), flags)
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("Casting your screen")
            .setContentText("Sharing with $peerName")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Stop", stop)
            .build()
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        ServiceCompat.startForeground(this, NOTE_ID, n, type)
    }

    companion object {
        const val ACTION_STOP = "com.mirrox.app.CAST_STOP"
        private const val CHANNEL = "cast"
        private const val NOTE_ID = 42

        /** Call from the UI right after the user allowed screen capture ([code] and [data] are that answer). */
        fun start(ctx: Context, code: Int, data: Intent, p: Peer, target: Int, fps: Int) {
            val i = Intent(ctx, CastService::class.java)
                .putExtra("code", code).putExtra("data", data)
                .putExtra("id", p.id).putExtra("name", p.name).putExtra("type", p.type)
                .putExtra("host", p.host).putExtra("port", p.port)
                .putExtra("target", target).putExtra("fps", fps)
            ContextCompat.startForegroundService(ctx, i)
        }

        fun stop(ctx: Context) {
            try {
                ctx.startService(Intent(ctx, CastService::class.java).setAction(ACTION_STOP))
            } catch (e: Exception) {
                ctx.stopService(Intent(ctx, CastService::class.java))
            }
        }
    }
}

/** One cast, start to finish. [execute] blocks until the cast has ended and always cleans up after itself. */
private class CastRun(
    private val ctx: Context, private val peer: Peer, private val code: Int, private val data: Intent,
    private val target: Int, private val fps: Int
) {
    private class Pkt(val type: Int, val pts: Long, val data: ByteArray)

    private class Enc(val codec: MediaCodec, val surface: Surface, val w: Int, val h: Int) {
        @Volatile var stop = false
        @Volatile var config: ByteArray? = null     // u16 w, u16 h, SPS+PPS
        var thread: Thread? = null

        fun shutdown() {
            stop = true
            try { thread?.join(1500) } catch (_: InterruptedException) {}
            try { codec.stop() } catch (_: Exception) {}
            try { codec.release() } catch (_: Exception) {}
            try { surface.release() } catch (_: Exception) {}
        }
    }

    @Volatile private var stopped = false
    @Volatile private var failure: String? = null
    private val q = LinkedBlockingQueue<Pkt>()
    private var waitKey = true                      // guarded by [q]
    private val sentBytes = AtomicLong()
    private val frames = AtomicInteger()

    private val ht = HandlerThread("mirrox-cast-cb").also { it.start() }
    private val handler = Handler(ht.looper)
    private val reconf = Any()
    @Volatile private var enc: Enc? = null
    private var vd: VirtualDisplay? = null
    private var landscape = false
    @Volatile private var rec: AudioRecord? = null
    private var audioThread: Thread? = null

    fun requestStop() { stopped = true }

    private fun failWith(msg: String) { if (failure == null) failure = msg; stopped = true }

    // ------------------------------------------------------------------ main flow
    fun execute() {
        var link: CastLink? = null
        var sender: Thread? = null
        var projection: MediaProjection? = null
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val listener = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) { if (displayId == Display.DEFAULT_DISPLAY) onRotate() }
        }
        try {
            val net = Cast.net ?: throw IOException("Mirrox is not ready. Open the app and try again.")
            val m = metrics()
            landscape = m.widthPixels > m.heightPixels

            // 1. encoder: the chosen quality, or smaller if this phone's encoder refuses that size
            var made: Enc? = null
            var last: Exception? = null
            for (t in listOf(target, 720, 480).filter { it <= target }.distinct()) {
                val (w, h) = fit(m.widthPixels, m.heightPixels, t)
                try { made = newEnc(w, h); break } catch (e: Exception) { last = e }
            }
            val e0 = made ?: throw (last ?: IOException("No H.264 encoder"))
            enc = e0

            // 2. secure connection to the PC; it must accept the cast before we capture anything
            val l: CastLink = net.openCast(peer, e0.w, e0.h, fps)
            link = l

            // 3. screen capture
            val mpm = ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = mpm.getMediaProjection(code, data) ?: throw SecurityException("no projection")
            projection = mp
            // Android 14 requires a callback to be registered before the first capture.
            mp.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { requestStop() }
            }, handler)
            vd = mp.createVirtualDisplay(
                "Mirrox", e0.w, e0.h, m.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                e0.surface, null, handler
            )

            // 3b. sound of the phone (Android 10+, needs the microphone permission; without it the cast has no sound)
            if (Build.VERSION.SDK_INT >= 29) startAudio(mp)

            // 4. go
            sender = Thread({ sendLoop(l) }, "mirrox-send").also { it.start() }
            startDrain(e0)
            dm.registerDisplayListener(listener, handler)
            Cast.phase = CastPhase.LIVE

            var wasPaused = false
            var lastStat = System.nanoTime(); var lastBytes = 0L; var lastFrames = 0
            while (!stopped) {
                try { Thread.sleep(150) } catch (_: InterruptedException) { break }
                val p = Cast.paused
                if (p != wasPaused) {
                    wasPaused = p
                    q.offer(Pkt(if (p) Cast.CP_PAUSE else Cast.CP_RESUME, 0, EMPTY))
                    if (!p) needKeyFrame()
                }
                val now = System.nanoTime()
                if (now - lastStat >= 1_000_000_000L) {
                    val secs = (now - lastStat) / 1e9
                    val b = sentBytes.get(); val f = frames.get()
                    val cur = enc
                    Cast.stats = "%dx%d  •  %d fps  •  %.1f Mbit/s".format(
                        cur?.w ?: 0, cur?.h ?: 0, ((f - lastFrames) / secs).roundToInt(), (b - lastBytes) * 8 / secs / 1e6
                    )
                    lastStat = now; lastBytes = b; lastFrames = f
                }
            }
        } catch (e: SecurityException) {
            failWith("Android did not allow screen capture. Try again.")
        } catch (e: Exception) {
            failWith(errText(e))
        } finally {
            stopped = true
            try { dm.unregisterDisplayListener(listener) } catch (_: Exception) {}
            stopAudio()
            synchronized(reconf) {
                enc?.shutdown()                      // no frames can follow the END packet
                enc = null
                try { vd?.release() } catch (_: Exception) {}
                vd = null
            }
            try { projection?.stop() } catch (_: Exception) {}
            if (link != null) {
                q.clear()
                q.offer(Pkt(Cast.CP_END, 0, EMPTY))
                try { sender?.join(1500) } catch (_: InterruptedException) {}
                link.close()
                try { sender?.join(500) } catch (_: InterruptedException) {}
            }
            ht.quitSafely()
            val f = failure
            if (f != null) Cast.fail(f) else Cast.reset()
        }
    }

    // ------------------------------------------------------------------ sending
    private fun sendLoop(l: CastLink) {
        val out: DataOutputStream = l.out
        try {
            while (true) {
                // keep-alive: the PC gives up on a silent connection after 15 s
                val p = q.poll(2, TimeUnit.SECONDS) ?: Pkt(Cast.CP_PING, 0, EMPTY)
                out.writeByte(p.type); out.writeInt(p.data.size); out.writeLong(p.pts)
                out.write(p.data)
                out.flush()
                sentBytes.addAndGet(p.data.size + 13L)
                if (p.type == Cast.CP_END) return
            }
        } catch (e: Exception) {
            if (!stopped) failWith("The other device closed the connection.")
            stopped = true
        }
    }

    /** Queue a frame. If the network can't keep up, skip ahead to the next key frame instead of building up delay. */
    private fun offer(pkts: List<Pkt>, key: Boolean) {
        synchronized(q) {
            if (!key && waitKey) return
            if (q.count { it.type == Cast.CP_KEY || it.type == Cast.CP_DELTA } >= MAX_QUEUE) {
                q.clear()
                waitKey = true
                requestSync()
                if (!key) return
            }
            if (key) waitKey = false
            pkts.forEach { q.offer(it) }
        }
    }

    private fun needKeyFrame() {
        synchronized(q) { waitKey = true }
        requestSync()
    }

    private fun requestSync() {
        val c = enc?.codec ?: return
        try { c.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) }) } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ audio
    /** Captures what the phone is playing (media, games) as PCM. Apps that forbid capture, and calls, stay silent. */
    @RequiresApi(29)
    private fun startAudio(mp: MediaProjection) {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(mp)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(AUDIO_RATE).setChannelMask(AudioFormat.CHANNEL_IN_STEREO).build()
            val min = AudioRecord.getMinBufferSize(AUDIO_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord.Builder()
                .setAudioFormat(fmt).setBufferSizeInBytes(maxOf(min, AUDIO_CHUNK * 8)).setAudioPlaybackCaptureConfig(cfg).build()
            if (r.state != AudioRecord.STATE_INITIALIZED) { r.release(); return }
            r.startRecording()
            rec = r
            audioThread = Thread({ audioLoop(r) }, "mirrox-audio").also { it.start() }
        } catch (_: Exception) {
            // no sound, the picture still works
        }
    }

    private fun audioLoop(r: AudioRecord) {
        val t0 = System.nanoTime()
        while (!stopped) {
            val buf = ByteArray(AUDIO_CHUNK)
            var got = 0
            while (got < AUDIO_CHUNK && !stopped) {
                val n = r.read(buf, got, AUDIO_CHUNK - got)
                if (n < 0) return                                   // capture ended
                if (n == 0) { try { Thread.sleep(5) } catch (_: InterruptedException) { return } }
                got += n
            }
            if (got < AUDIO_CHUNK || Cast.paused) continue
            if (q.size < MAX_AUDIO_BACKLOG) q.offer(Pkt(Cast.CP_AUDIO, (System.nanoTime() - t0) / 1000, buf))
        }
    }

    private fun stopAudio() {
        val r = rec
        rec = null
        try { r?.stop() } catch (_: Exception) {}
        try { audioThread?.join(500) } catch (_: InterruptedException) {}
        audioThread = null
        try { r?.release() } catch (_: Exception) {}
    }

    // ------------------------------------------------------------------ encoder
    private fun startDrain(e: Enc) {
        e.thread = Thread({ drain(e) }, "mirrox-drain").also { it.start() }
    }

    private fun drain(e: Enc) {
        val info = MediaCodec.BufferInfo()
        while (!e.stop && !stopped) {
            val i = try { e.codec.dequeueOutputBuffer(info, 100_000L) } catch (ex: Exception) { break }
            if (i < 0) continue                      // timeout, or the output format changed
            var bytes: ByteArray? = null
            try {
                val b = e.codec.getOutputBuffer(i)
                if (b != null && info.size > 0) {
                    b.position(info.offset); b.limit(info.offset + info.size)
                    bytes = ByteArray(info.size); b.get(bytes)
                }
            } finally {
                try { e.codec.releaseOutputBuffer(i, false) } catch (_: Exception) {}
            }
            val d = bytes ?: continue
            if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                e.config = ByteBuffer.allocate(4 + d.size).putShort(e.w.toShort()).putShort(e.h.toShort()).put(d).array()
                continue
            }
            if (Cast.paused) continue
            frames.incrementAndGet()
            if ((info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0) {
                // parameter sets travel in front of every key frame, so the PC can start decoding at any of them
                val cfg = e.config
                val list = ArrayList<Pkt>(2)
                if (cfg != null) list.add(Pkt(Cast.CP_CONFIG, 0, cfg))
                list.add(Pkt(Cast.CP_KEY, info.presentationTimeUs, d))
                offer(list, true)
            } else {
                offer(listOf(Pkt(Cast.CP_DELTA, info.presentationTimeUs, d)), false)
            }
        }
    }

    private fun newEnc(w: Int, h: Int): Enc {
        // about 0.07 bit per pixel suits screen content; 1..20 Mbit/s
        val bitrate = (w.toLong() * h * fps * 0.07).toLong().coerceIn(1_000_000L, 20_000_000L).toInt()
        var last: Exception? = null
        for (cbr in listOf(true, false)) {
            var codec: MediaCodec? = null
            try {
                val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
                f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                f.setInteger(MediaFormat.KEY_PRIORITY, 0)                              // real time
                f.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 500_000L)       // still screen: 2 frames/s
                if (cbr) f.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)
                if (Build.VERSION.SDK_INT >= 29) {
                    f.setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)
                    f.setFloat(MediaFormat.KEY_MAX_FPS_TO_ENCODER, fps.toFloat())
                }
                if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LATENCY, 1)
                codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
                codec.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val surface = codec.createInputSurface()
                codec.start()
                return Enc(codec, surface, w, h)
            } catch (e: Exception) {
                last = e
                try { codec?.release() } catch (_: Exception) {}
            }
        }
        throw last ?: IOException("No H.264 encoder")
    }

    // ------------------------------------------------------------------ rotation
    /** Screen rotated: the picture changes between portrait and landscape, so switch to an encoder of the new shape. */
    private fun onRotate() {
        synchronized(reconf) {
            val display = vd ?: return
            if (stopped) return
            val m = metrics()
            val land = m.widthPixels > m.heightPixels
            if (land == landscape) return
            val old = enc ?: return
            val (w, h) = fit(m.widthPixels, m.heightPixels, minOf(target, minOf(old.w, old.h)))
            val next = try { newEnc(w, h) } catch (e: Exception) { return }   // keep the old picture size
            landscape = land
            try {
                display.resize(w, h, m.densityDpi)
                display.setSurface(next.surface)
            } catch (e: Exception) {
                next.shutdown()
                return
            }
            enc = next
            old.shutdown()                           // its last packets are queued before the new CONFIG
            needKeyFrame()                           // (before the drain starts, so the first key frame is kept)
            startDrain(next)
        }
    }

    // ------------------------------------------------------------------ helpers
    @Suppress("DEPRECATION")
    private fun metrics(): DisplayMetrics {
        val m = DisplayMetrics()
        val d = (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).getDisplay(Display.DEFAULT_DISPLAY)
        d.getRealMetrics(m)
        return m
    }

    /** Scale (screen width x height) so the short side is at most [shortSide]; both sides become multiples of 16. */
    private fun fit(w: Int, h: Int, shortSide: Int): Pair<Int, Int> {
        val s = minOf(w, h)
        val k = if (s > shortSide) shortSide.toFloat() / s else 1f
        fun r(v: Int) = maxOf(16, (v * k / 16f).roundToInt() * 16)
        return r(w) to r(h)
    }

    companion object {
        private val EMPTY = ByteArray(0)
        private const val MAX_QUEUE = 20   // video packets, about 0.7 s at 30 fps
        private const val AUDIO_RATE = 48000
        private const val AUDIO_CHUNK = AUDIO_RATE * 2 * 2 / 50   // 20 ms of stereo 16-bit
        private const val MAX_AUDIO_BACKLOG = 250                // about 5 s: if the network stalls, drop sound instead of piling up
    }
}
