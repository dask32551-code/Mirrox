plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "com.mirrox.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.mirrox.app"; minSdk = 24; targetSdk = 34; versionCode = 2; versionName = "1.1.0" }
    // One fixed key, so every new build installs over the previous one.
    signingConfigs {
        create("mirrox") {
            storeFile = file("mirrox.jks"); storePassword = "mirrox123"; keyAlias = "mirrox"; keyPassword = "mirrox123"
        }
    }
    buildTypes {
        // Both build types are optimised (R8 + no debug flag): Compose is several times slower in a plain debug build.
        // "debug" keeps its name so CI still produces app/build/outputs/apk/debug/app-debug.apk.
        debug {
            isDebuggable = false
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("mirrox")
        }
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            signingConfig = signingConfigs.getByName("mirrox")
        }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.09.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.activity:activity-compose:1.9.2")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    implementation("com.google.zxing:core:3.5.3")
}
