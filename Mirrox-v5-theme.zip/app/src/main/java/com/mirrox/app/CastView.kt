package com.mirrox.app

import android.media.MediaCodec
import android.media.MediaFormat
import android.os.Build
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.io.DataInputStream
import java.io.IOException
import java.net.Socket
import java.nio.ByteBuffer

/*
 * Receiving a screen cast on Android (the phone shows another device's screen).
 * Packet format: PROTOCOL.md, "Screen cast". Decoding: MediaCodec H.264 straight onto a SurfaceView.
 */

/** One incoming cast. [run] blocks on the network thread; the UI shows [ViewerScreen] while it exists. */
class ViewerSession(val peerName: String, w: Int, h: Int, private val sock: Socket) {
    var size by mutableStateOf(w to h)
    var paused by mutableStateOf(false)

    private val lock = Object()
    private var surface: Surface? = null
    private var hadSurface = false
    @Volatile private var stopped = false
    @Volatile private var dec: MediaCodec? = null

    fun stop() {
        stopped = true
        synchronized(lock) { lock.notifyAll() }
        try { sock.close() } catch (_: IOException) {}
    }

    /** The picture surface appeared (non-null) or went away (null: the user left the screen, which ends the cast). */
    fun setSurface(s: Surface?) {
        synchronized(lock) {
            surface = s
            if (s != null) hadSurface = true
            lock.notifyAll()
        }
        if (s == null && hadSurface) stop()
    }

    private fun awaitSurface(ms: Long): Surface? {
        val end = System.currentTimeMillis() + ms
        synchronized(lock) {
            while (surface == null && !stopped) {
                val left = end - System.currentTimeMillis()
                if (left <= 0) break
                lock.wait(left)
            }
            return surface
        }
    }

    fun run(inp: DataInputStream) {
        val s = awaitSurface(30_000) ?: return        // nobody opened the viewer
        val drain = Thread({ drain() }, "mirrox-view-out")
        var cfg = ByteArray(0)
        var haveKey = false
        var w = size.first; var h = size.second
        try {
            dec = newDecoder(w, h, s)
            drain.start()
            while (!stopped) {
                val type = inp.readUnsignedByte()
                val n = inp.readInt()
                val pts = inp.readLong()
                if (n < 0 || n > MAX_PKT) throw IOException("packet too large")
                val data = ByteArray(n)
                inp.readFully(data)
                when (type) {
                    Cast.CP_END -> return
                    Cast.CP_PAUSE -> paused = true
                    Cast.CP_RESUME -> paused = false
                    Cast.CP_CONFIG -> if (n > 4) {
                        val nw = ((data[0].toInt() and 0xFF) shl 8) or (data[1].toInt() and 0xFF)
                        val nh = ((data[2].toInt() and 0xFF) shl 8) or (data[3].toInt() and 0xFF)
                        cfg = data.copyOfRange(4, n)
                        if (nw in 16..8192 && nh in 16..8192 && (nw != w || nh != h)) {
                            // the sender rotated: new picture size, new decoder
                            w = nw; h = nh
                            val old = dec
                            dec = null
                            try { old?.stop() } catch (_: Exception) {}
                            try { old?.release() } catch (_: Exception) {}
                            dec = newDecoder(w, h, s)
                            haveKey = false
                            size = w to h
                        }
                    }
                    Cast.CP_KEY -> if (feed(cfg + data, pts)) { haveKey = true; paused = false }
                    Cast.CP_DELTA -> if (haveKey) {
                        if (feed(data, pts)) paused = false else haveKey = false
                    }
                    else -> {}                          // ping, or something newer than us
                }
            }
        } finally {
            stopped = true
            val d = dec
            dec = null
            try { drain.join(500) } catch (_: InterruptedException) {}
            try { d?.stop() } catch (_: Exception) {}
            try { d?.release() } catch (_: Exception) {}
        }
    }

    private fun newDecoder(w: Int, h: Int, s: Surface): MediaCodec {
        val c = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        try {
            val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
            if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
            c.configure(f, s, null, 0)
            c.start()
            return c
        } catch (e: Exception) {
            try { c.release() } catch (_: Exception) {}
            throw e
        }
    }

    /** Hand one access unit to the decoder. False if it had to be dropped (the caller then waits for a key frame). */
    private fun feed(data: ByteArray, pts: Long): Boolean {
        val c = dec ?: return false
        return try {
            val i = c.dequeueInputBuffer(30_000L)
            if (i < 0) return false
            val b: ByteBuffer = c.getInputBuffer(i) ?: return false
            if (data.size > b.capacity()) return false
            b.clear(); b.put(data)
            c.queueInputBuffer(i, 0, data.size, pts, 0)
            true
        } catch (e: Exception) { false }
    }

    private fun drain() {
        val info = MediaCodec.BufferInfo()
        while (!stopped) {
            val c = dec
            if (c == null) { try { Thread.sleep(5) } catch (_: InterruptedException) { return }; continue }
            try {
                val i = c.dequeueOutputBuffer(info, 10_000L)
                if (i >= 0) c.releaseOutputBuffer(i, true)       // true: show it now
            } catch (e: Exception) {
                try { Thread.sleep(5) } catch (_: InterruptedException) { return }   // decoder being replaced
            }
        }
    }

    companion object { private const val MAX_PKT = 16 * 1024 * 1024 }
}

/** Full-screen picture of the other device's screen. Back or Stop ends the cast. */
@Composable
fun ViewerScreen(v: ViewerSession) {
    Dialog(
        onDismissRequest = { v.stop() },
        properties = DialogProperties(dismissOnBackPress = true, dismissOnClickOutside = false, usePlatformDefaultWidth = false)
    ) {
        Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            val ratio = (v.size.first.toFloat() / v.size.second).coerceIn(0.2f, 5f)
            AndroidView(
                modifier = Modifier.aspectRatio(ratio),
                factory = { ctx ->
                    SurfaceView(ctx).apply {
                        keepScreenOn = true
                        holder.addCallback(object : SurfaceHolder.Callback {
                            override fun surfaceCreated(h: SurfaceHolder) { v.setSurface(h.surface) }
                            override fun surfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) {}
                            override fun surfaceDestroyed(h: SurfaceHolder) { v.setSurface(null) }
                        })
                    }
                }
            )
            Box(Modifier.align(Alignment.TopEnd).padding(16.dp)) {
                Btn("Stop", true, small = true) { v.stop() }
            }
            if (v.paused) Box(Modifier.align(Alignment.Center)) { Tx("Paused", 18, col = Color.White) }
            Box(Modifier.align(Alignment.TopStart).padding(16.dp)) { Tx(v.peerName, 12, col = Color.White.copy(alpha = 0.7f)) }
        }
    }
}
