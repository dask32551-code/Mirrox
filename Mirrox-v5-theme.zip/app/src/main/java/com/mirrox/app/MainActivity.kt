package com.mirrox.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.net.Uri
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.core.Animatable
import androidx.compose.ui.graphics.lerp
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.outlined.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Send
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // Start with the correct theme on the very first frame (no light flash in dark mode).
        isDark = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        themeT = if (isDark) 1f else 0f
        setContent { App() }
    }
}

// ---------------------------------------------------------------- Design tokens
// Soft light-blue page, white rounded cards with a gentle shadow, navy text, one blue accent.

class Pal(val bg: Color, val sf: Color, val tx: Color, val mu: Color, val bd: Color, val ac: Color, val pl: Color, val tl: Color)

val Light = Pal(
    bg = Color(0xFFEEF5FB), sf = Color(0xFFFFFFFF), tx = Color(0xFF0F1A52), mu = Color(0xFF6A7787),
    bd = Color(0xFFE9EEF5), ac = Color(0xFF1F5FEA), pl = Color(0xFFE8F0FB), tl = Color(0xFFDCE6F3)
)
val Dark = Pal(
    bg = Color(0xFF0C1220), sf = Color(0xFF151D2E), tx = Color(0xFFEAF0FF), mu = Color(0xFF93A0B8),
    bd = Color(0xFF232C40), ac = Color(0xFF5B8DFF), pl = Color(0xFF1C2B4D), tl = Color(0xFF26324A)
)
val Ok = Color(0xFF10B396)

var isDark by mutableStateOf(false)
/** 0 = light palette, 1 = dark palette; animated so switching theme fades instead of snapping. */
var themeT by mutableFloatStateOf(0f)
private fun mix(a: Pal, b: Pal, t: Float) = Pal(
    lerp(a.bg, b.bg, t), lerp(a.sf, b.sf, t), lerp(a.tx, b.tx, t), lerp(a.mu, b.mu, t),
    lerp(a.bd, b.bd, t), lerp(a.ac, b.ac, t), lerp(a.pl, b.pl, t), lerp(a.tl, b.tl, t)
)
val c: Pal get() = when (themeT) { 0f -> Light; 1f -> Dark; else -> mix(Light, Dark, themeT) }

val Rad = 16.dp
val Medium = FontWeight.Medium
val SemiBold = FontWeight.SemiBold
val Bold = FontWeight.Bold

// ---------------------------------------------------------------- Building blocks

@Composable
fun Tx(t: String, s: Int = 14, w: FontWeight = FontWeight.Normal, col: Color = c.tx, mod: Modifier = Modifier, al: TextAlign? = null, ls: Float = 0f) =
    Text(text = t, modifier = mod, color = col, fontSize = s.sp, fontWeight = w, textAlign = al, lineHeight = (s * 1.4f).sp, letterSpacing = ls.sp)

@Composable
fun Ic(v: ImageVector, col: Color = c.mu, s: Int = 24) = Icon(v, null, Modifier.size(s.dp), tint = col)

fun Modifier.box(bg: Color, r: Dp = Rad): Modifier {
    val shape = RoundedCornerShape(r)
    val base = if (isDark) this else this.shadow(4.dp, shape, ambientColor = Color(0x1A1F3A6E), spotColor = Color(0x261F3A6E))
    val m = base.clip(shape).background(bg)
    return if (isDark) m.border(1.dp, c.bd, shape) else m
}

/** Fades and rises into place when first shown; [i] staggers siblings. */
@Composable
fun Modifier.appear(i: Int = 0): Modifier {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { delay(i * 45L); a.animateTo(1f, tween(360, easing = FastOutSlowInEasing)) }
    return this.graphicsLayer { alpha = a.value; translationY = (1f - a.value) * 18.dp.toPx() }
}

/** Springy "press in" while a finger is down; pass the same [src] to the clickable that follows. */
@Composable
fun Modifier.tapScale(src: MutableInteractionSource, to: Float = 0.96f): Modifier {
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) to else 1f, spring(dampingRatio = 0.55f, stiffness = 600f), label = "tap")
    return this.graphicsLayer { scaleX = sc; scaleY = sc }
}

/** A card that shrinks slightly when pressed, ripples inside its rounded shape, and springs back. */
@Composable
fun Modifier.tapBox(bg: Color, r: Dp = Rad, to: Float = 0.97f, onClick: () -> Unit): Modifier {
    val src = remember { MutableInteractionSource() }
    return this.tapScale(src, to).box(bg, r).clickable(src, LocalIndication.current) { onClick() }
}

/** Round, tinted background behind an icon. */
@Composable
fun IcCircle(v: ImageVector, size: Int = 48, icon: Int = 24) =
    Box(Modifier.size(size.dp).clip(CircleShape).background(c.pl), Alignment.Center) { Ic(v, c.ac, icon) }

@Composable
fun Sec(t: String, top: Int = 24, right: @Composable () -> Unit = {}) =
    Row(Modifier.fillMaxWidth().padding(top = top.dp, bottom = 12.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
        Tx(t, 20, Bold); right()
    }

@Composable
fun Scanning() {
    val a by rememberInfiniteTransition(label = "scan").animateFloat(0.25f, 1f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "scanAlpha")
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(c.ac.copy(alpha = a)))
        Spacer(Modifier.width(8.dp))
        Tx("Scanning", 14, Medium, c.mu)
    }
}

@Composable
fun Head(t: String, back: (() -> Unit)? = null) =
    Row(Modifier.fillMaxWidth().padding(bottom = 20.dp), verticalAlignment = Alignment.CenterVertically) {
        if (back != null) Box(Modifier.offset(x = (-8).dp).size(44.dp).clip(CircleShape).clickable { back() }, Alignment.Center) {
            Ic(Icons.AutoMirrored.Outlined.ArrowBack, c.tx, 26)
        }
        Tx(t, 28, Bold, mod = Modifier.padding(start = if (back != null) 4.dp else 0.dp))
    }

@Composable
fun Btn(t: String, filled: Boolean = false, mod: Modifier = Modifier, small: Boolean = false, onClick: () -> Unit) {
    val shape = RoundedCornerShape(if (small) 12.dp else 14.dp)
    val src = remember { MutableInteractionSource() }
    Box(
        mod.tapScale(src, 0.95f).heightIn(min = if (small) 36.dp else 50.dp).clip(shape)
            .background(if (filled) c.ac else c.sf)
            .border(1.dp, if (filled) c.ac else if (isDark) c.bd else Color(0xFFD5E1F3), shape)
            .clickable(src, LocalIndication.current) { onClick() }
            .padding(horizontal = if (small) 14.dp else 16.dp, vertical = 8.dp),
        Alignment.Center
    ) { Tx(t, 14, SemiBold, if (filled) Color.White else c.ac) }
}

@Composable
fun Item(icon: ImageVector, title: String, sub: String, act: @Composable () -> Unit = {}) =
    Row(
        Modifier.fillMaxWidth().appear().padding(bottom = 12.dp).box(c.sf).padding(start = 14.dp, end = 12.dp, top = 12.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IcCircle(icon, 44, 22); Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) { Tx(title, 16, SemiBold); Tx(sub, 13, col = c.mu) }
        act()
    }

@Composable
fun Dlg(title: String, dismiss: () -> Unit, confirm: @Composable () -> Unit = {}, cancel: (@Composable () -> Unit)? = null, body: @Composable () -> Unit) =
    AlertDialog(
        onDismissRequest = dismiss, containerColor = c.sf, shape = RoundedCornerShape(24.dp),
        title = { Tx(title, 18, Bold) }, text = body, confirmButton = confirm, dismissButton = cancel
    )

@Composable
fun TBtn(t: String, onClick: () -> Unit) = TextButton(onClick) { Text(t, color = c.ac, fontSize = 14.sp, fontWeight = SemiBold) }


// Real, scannable QR code (ZXing).
@Composable
fun Qr(text: String) {
    val m = remember(text) {
        runCatching { QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, 0, 0, mapOf(EncodeHintType.MARGIN to 0)) }.getOrNull()
    }
    Canvas(Modifier.size(192.dp).box(Color.White).padding(16.dp)) {
        if (m != null) {
            val u = size.width / m.width
            for (y in 0 until m.height) for (x in 0 until m.width) {
                if (m.get(x, y)) drawRect(Color(0xFF111111), Offset(x * u, y * u), Size(u + 0.5f, u + 0.5f))
            }
        }
    }
}

fun fmt(b: Long): String = when {
    b >= 1_073_741_824L -> "%.1f GB".format(b / 1_073_741_824.0)
    b >= 1_048_576L -> "%.1f MB".format(b / 1_048_576.0)
    b >= 1024L -> "${b / 1024} KB"
    else -> "$b B"
}

fun iconFor(t: String): ImageVector = when (t) {
    "android", "ios" -> Icons.Outlined.Smartphone
    "windows", "linux", "mac" -> Icons.Outlined.DesktopWindows
    else -> Icons.Outlined.Devices
}

fun ago(t: Long): String {
    val m = (System.currentTimeMillis() - t) / 60000
    return when { m < 1 -> "Just now"; m < 60 -> "$m min ago"; m < 1440 -> "${m / 60} h ago"; else -> "${m / 1440} d ago" }
}

/** "192.168.1.5" or "192.168.1.5:48500" */
fun parseAddr(s: String): Pair<String, Int>? {
    val t = s.trim()
    if (t.isEmpty()) return null
    val i = t.lastIndexOf(':')
    if (i > 0 && t.count { it == ':' } == 1) {
        val p = t.substring(i + 1).toIntOrNull() ?: return null
        return t.substring(0, i) to p
    }
    return t to Proto.PORT
}

@Composable
fun Empty(t: String) = Tx(t, 13, col = c.mu, mod = Modifier.padding(bottom = 8.dp))

/** Phone + monitor with Wi-Fi on a soft blob: the "nothing nearby yet" picture. */
@Composable
fun NearbyArt() {
    val ac = c.ac
    val blob = if (isDark) Color(0xFF1C2B4D) else Color(0xFFE6F0FC)
    val fill = c.sf
    Canvas(Modifier.size(width = 220.dp, height = 124.dp)) {
        val u = 1.dp.toPx()
        drawCircle(blob, 58 * u, Offset(112 * u, 66 * u))
        drawCircle(blob.copy(alpha = 0.7f), 13 * u, Offset(30 * u, 36 * u))
        drawCircle(blob.copy(alpha = 0.7f), 6 * u, Offset(204 * u, 46 * u))
        // monitor
        val mTop = Offset(72 * u, 20 * u); val mSize = Size(104 * u, 66 * u)
        drawRoundRect(fill, mTop, mSize, CornerRadius(7 * u))
        drawRoundRect(ac, mTop, mSize, CornerRadius(7 * u), Stroke(3 * u))
        drawLine(ac, Offset(124 * u, 86 * u), Offset(124 * u, 100 * u), 3 * u, StrokeCap.Round)
        drawLine(ac, Offset(104 * u, 102 * u), Offset(144 * u, 102 * u), 4 * u, StrokeCap.Round)
        // wifi
        val o = Offset(124 * u, 62 * u)
        drawCircle(ac, 3 * u, o)
        for (r in listOf(10, 19, 28)) drawArc(
            ac, -135f, 90f, false, Offset(o.x - r * u, o.y - r * u), Size(2 * r * u, 2 * r * u), style = Stroke(3 * u, cap = StrokeCap.Round)
        )
        // phone
        val pTop = Offset(30 * u, 48 * u); val pSize = Size(34 * u, 60 * u)
        drawRoundRect(fill, pTop, pSize, CornerRadius(8 * u))
        drawRoundRect(ac.copy(alpha = 0.22f), Offset(34 * u, 88 * u), Size(26 * u, 16 * u), CornerRadius(5 * u))
        drawRoundRect(ac, pTop, pSize, CornerRadius(8 * u), Stroke(3 * u))
        drawLine(ac, Offset(43 * u, 54 * u), Offset(51 * u, 54 * u), 2.5f * u, StrokeCap.Round)
    }
}

@Composable
fun NearbyEmpty() =
    Column(Modifier.fillMaxWidth().appear(2).box(c.sf, 20.dp).padding(horizontal = 16.dp, vertical = 24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        NearbyArt()
        Spacer(Modifier.height(16.dp))
        Tx("No devices found yet.", 17, Bold, al = TextAlign.Center)
        Spacer(Modifier.height(4.dp))
        Tx("Keep both devices on the same Wi-Fi.", 14, col = c.mu, al = TextAlign.Center)
    }

@Composable
fun NearbyList(peers: List<Peer>, label: String, go: (Peer) -> Unit) {
    Column(Modifier.fillMaxWidth().animateContentSize(spring(stiffness = Spring.StiffnessMediumLow))) {
        if (peers.isEmpty()) NearbyEmpty()
        else peers.forEach { p -> Item(iconFor(p.type), p.name, typeLabel(p.type)) { Btn(label, small = true) { go(p) } } }
    }
}

// ---------------------------------------------------------------- Data

class SRow(
    val l: String, val k: String? = null, val o: List<String> = emptyList(), val v: String? = null, val i: String? = null,
    val edit: Boolean = false, val ic: ImageVector? = null, val sw: Boolean = false
)

val SETS = listOf(
    "General" to listOf(
        SRow("Device Name", "name", edit = true, ic = Icons.Outlined.DesktopWindows),
        SRow("Theme", "theme", listOf("Light", "Dark", "System default"), ic = Icons.Outlined.Palette)
    ),
    "Casting" to listOf(
        SRow("Video Quality", "q", listOf("High (1080p)", "Medium (720p)", "Low (480p)", "Auto"), ic = Icons.Outlined.SmartDisplay),
        SRow("FPS", "fps", listOf("60 FPS", "30 FPS"))
    ),
    "Files" to listOf(
        SRow("Download Location", ic = Icons.Outlined.Download),
        SRow("Recording Location", v = "Movies/Mirrox", i = "Screen recordings will be saved to this folder.", ic = Icons.Outlined.Folder)
    ),
    "Connections" to listOf(
        SRow("Trusted Devices", ic = Icons.Outlined.Link),
        SRow("Auto Reconnect", "ar", listOf("On", "Off"), ic = Icons.Outlined.Sync, sw = true)
    ),
    "Privacy" to listOf(
        SRow("Clipboard Sharing", "cb", listOf("Ask every time", "Always allow", "Off"), ic = Icons.Outlined.ContentPaste),
        SRow("Connection Permissions", "cp", listOf("Always confirm", "Trust known devices"), ic = Icons.Outlined.Shield)
    ),
    "About" to listOf(
        SRow("Mirrox Version", ic = Icons.Outlined.Info),
        SRow("Privacy", i = "Mirrox does not collect personal data. Your screen and files go directly between your devices.", ic = Icons.Outlined.PrivacyTip),
        SRow("Licenses", i = "Mirrox uses Jetpack Compose and ZXing, both licensed under Apache 2.0.", ic = Icons.Outlined.Description)
    )
)

/** Small "FPS" badge used as the icon of the FPS row. */
@Composable
fun FpsIcon() =
    Box(Modifier.size(24.dp).border(2.dp, c.ac, RoundedCornerShape(6.dp)), Alignment.Center) {
        Text("FPS", color = c.ac, fontSize = 8.sp, fontWeight = Bold, lineHeight = 8.sp)
    }

/** Asks for a PIN. [peer] == null means manual entry (address + PIN). */
class PinReq(val peer: Peer?, val then: (Peer) -> Unit)
class Picked(val uri: Uri, val name: String, val size: Long)

// ---------------------------------------------------------------- App

@Composable
fun App() {
    val sys = isSystemInDarkTheme()
    val ctx = LocalContext.current
    val net = remember { Net(ctx.applicationContext) }
    DisposableEffect(net) { Cast.net = net; net.start(); onDispose { net.stop() } }

    val sp = remember { ctx.getSharedPreferences("mirrox_ui", Context.MODE_PRIVATE) }
    val st = remember {
        mutableStateMapOf(
            "theme" to "System default", "q" to "High (1080p)", "fps" to "30 FPS",
            "ar" to "On", "cb" to "Ask every time", "cp" to "Always confirm"
        ).also { m ->
                m.keys.toList().forEach { k -> sp.getString(k, null)?.let { v -> m[k] = v } }
                if (m["ar"] != "Off") m["ar"] = "On"
            }
    }
    fun setSt(k: String, v: String) { st[k] = v; sp.edit().putString(k, v).apply() }
    val appVer = remember { runCatching { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName }.getOrNull() ?: "1.0" }

    LaunchedEffect(st["theme"], sys) { isDark = when (st["theme"]) { "Dark" -> true; "Light" -> false; else -> sys } }
    LaunchedEffect(isDark) { Animatable(themeT).animateTo(if (isDark) 1f else 0f, tween(350)) { themeT = value } }
    val view = LocalView.current
    SideEffect {
        WindowCompat.getInsetsController((view.context as Activity).window, view).apply {
            isAppearanceLightStatusBars = !isDark; isAppearanceLightNavigationBars = !isDark
        }
    }

    var tab by remember { mutableIntStateOf(0) }
    var sub by remember { mutableStateOf<String?>(null) }
    var target by remember { mutableStateOf<Peer?>(null) }      // destination for Send Files
    var castPeer by remember { mutableStateOf<Peer?>(null) }    // device we are casting to
    var live by remember { mutableStateOf(false) }
    var secs by remember { mutableIntStateOf(0) }
    var file by remember { mutableStateOf<Picked?>(null) }
    var capFor by remember { mutableStateOf<Peer?>(null) }
    var info by remember { mutableStateOf<Pair<String, String>?>(null) }
    var choice by remember { mutableStateOf<SRow?>(null) }
    var pinReq by remember { mutableStateOf<PinReq?>(null) }
    var nameD by remember { mutableStateOf(false) }

    val trusted = net.known.filter { it.canConnect || it.issued != null }
    val trustedText = if (trusted.isEmpty()) "None yet" else "${trusted.size} device" + if (trusted.size > 1) "s" else ""
    val trustedInfo = if (trusted.isEmpty()) "Devices you pair with a PIN or QR code appear here." else trusted.joinToString("\n") { "${it.name} (${typeLabel(it.type)})" }

    // Screen capture: (1) notification permission (so the "casting" notification shows), (2) Android's own
    // "start recording or casting?" dialog, (3) the foreground service does the rest.
    val mpm = remember { ctx.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }
    val projection = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val p = castPeer
        val d = r.data
        if (r.resultCode == Activity.RESULT_OK && d != null && p != null) {
            Cast.begin(p)
            CastService.start(ctx, r.resultCode, d, p, Cast.targetFor(st["q"]), Cast.fpsFor(st["fps"]))
        } else {
            sub = null
            info = "Screen capture not allowed" to "Mirrox can only share your screen after you allow it."
        }
    }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { _ ->
        projection.launch(mpm.createScreenCaptureIntent())     // casting works without notifications too
    }
    fun askCapture() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        else projection.launch(mpm.createScreenCaptureIntent())
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            val d = net.describe(u)
            if (d == null) info = "Can't send this file" to "Mirrox couldn't read the size of this file."
            else file = Picked(u, d.first, d.second)
        }
    }

    LaunchedEffect(live) { if (live) { secs = 0; while (true) { delay(1000); if (!Cast.paused) secs++ } } }
    // "Connecting…" first checks that the device is reachable and still trusts us; only then do we ask Android
    // for permission to capture the screen. The service connects again and starts streaming.
    LaunchedEffect(sub) {
        if (sub == "conn") {
            val p = castPeer
            if (p == null) sub = null
            else net.verify(p) { r ->
                r.onSuccess { askCapture() }
                    .onFailure { e -> sub = null; info = "Couldn't connect" to errText(e) }
            }
        }
    }
    // The service reports back through Cast: streaming started, or it ended (on purpose or not).
    LaunchedEffect(Cast.phase) {
        when (Cast.phase) {
            CastPhase.LIVE -> { if (castPeer == null) castPeer = Cast.peer; live = true; sub = "active" }
            CastPhase.FAILED -> {
                live = false
                if (sub == "conn" || sub == "active") sub = null
                info = "Casting stopped" to (Cast.error ?: "Something went wrong.")
                Cast.reset()
            }
            CastPhase.IDLE -> { live = false; if (sub == "conn" || sub == "active") sub = null }
            CastPhase.CONNECTING -> {}
        }
    }
    BackHandler(sub != null && sub != "conn") { sub = if (sub == "dest") "send" else null }

    // A device was chosen (and is paired): pick it as destination, or start the cast flow.
    fun chosen(p: Peer) { if (sub == "dest") { target = p; sub = "send" } else capFor = p }
    fun pick(p: Peer) { if (net.canConnect(p)) chosen(p) else pinReq = PinReq(p) { q -> chosen(q) } }

    val scanner = rememberLauncherForActivityResult(ScanContract()) { res ->
        res.contents?.let { text ->
            val pr = net.parseQr(text)
            if (pr == null) info = "Not a Mirrox code" to "Scan the QR code shown on another Mirrox device."
            else net.pairQr(pr) { r -> r.onSuccess { p -> chosen(p) }.onFailure { e -> info = "Couldn't connect" to errText(e) } }
        }
    }
    fun scan() {
        scanner.launch(ScanOptions().setDesiredBarcodeFormats(ScanOptions.QR_CODE).setPrompt("Scan a Mirrox QR code").setBeepEnabled(false).setOrientationLocked(false))
    }
    fun startSend(p: Peer) {
        val f = file ?: return
        target = p; tab = 2; sub = null
        net.sendFile(p, f.uri, f.name, f.size, null) { r ->
            r.onFailure { e -> if ((e as? NetError)?.msg != "cancelled") info = "Transfer failed" to errText(e) }
            if (file === f) file = null
        }
    }
    fun time() = "%02d:%02d".format(secs / 60, secs % 60)

    val screen = sub ?: listOf("home", "devices", "transfers", "settings")[tab]

    Column(Modifier.fillMaxSize().background(c.bg)) {
        AnimatedContent(
            targetState = screen, modifier = Modifier.weight(1f).fillMaxWidth(), label = "page",
            transitionSpec = {
                val tabs = listOf("home", "devices", "transfers", "settings")
                val a = tabs.indexOf(initialState); val b = tabs.indexOf(targetState)
                val dir = when { a >= 0 && b >= 0 -> if (b > a) 1 else -1; b < 0 -> 1; else -> -1 }
                (slideInHorizontally(tween(300, easing = FastOutSlowInEasing)) { dir * it / 6 } + fadeIn(tween(240))) togetherWith
                    (slideOutHorizontally(tween(220, easing = FastOutSlowInEasing)) { -dir * it / 6 } + fadeOut(tween(140))) using
                    SizeTransform(clip = false)
            }
        ) { s ->
            Column(Modifier.fillMaxSize().statusBarsPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 20.dp)) {
                when (s) {
                    "home" -> {
                        Column(Modifier.appear(0).padding(bottom = 20.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(50.dp).border(3.dp, c.ac, RoundedCornerShape(13.dp)), Alignment.Center) { Ic(Icons.Outlined.Cast, c.ac, 30) }
                                Spacer(Modifier.width(12.dp))
                                Tx("Mirrox", 32, Bold, mod = Modifier.weight(1f))
                                Box(Modifier.size(44.dp).clip(CircleShape).clickable { tab = 3; sub = null }, Alignment.Center) { Ic(Icons.Outlined.Settings, c.ac, 28) }
                            }
                            Spacer(Modifier.height(2.dp))
                            val x = net.current
                            Row(Modifier.padding(start = 62.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(9.dp).clip(CircleShape).background(if (live || x != null) c.ac else Ok))
                                Spacer(Modifier.width(8.dp))
                                Tx(
                                    when {
                                        live -> "Connected to ${castPeer?.name ?: ""}"
                                        x != null -> (if (x.sending) "Sending " else "Receiving ") + x.name
                                        else -> "Ready to connect"
                                    }, 16, col = c.mu
                                )
                            }
                        }
                        @Composable
                        fun Tile(i: ImageVector, t: String, d: String, m: Modifier, go: () -> Unit) =
                            Column(m.tapBox(c.sf, 20.dp, 0.96f) { go() }.padding(16.dp)) {
                                IcCircle(i, 52, 26); Spacer(Modifier.height(14.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Tx(t, 17, Bold, mod = Modifier.weight(1f)); Ic(Icons.Outlined.ChevronRight, c.mu, 22)
                                }
                                Spacer(Modifier.height(4.dp)); Tx(d, 14, col = c.mu)
                            }
                        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), Arrangement.spacedBy(14.dp)) {
                            Tile(Icons.Outlined.Cast, "Cast Screen", "Share this device's screen.", Modifier.weight(1f).fillMaxHeight().appear(1)) { sub = "cast" }
                            Tile(Icons.Outlined.DesktopWindows, "Receive Screen", "View another device's screen.", Modifier.weight(1f).fillMaxHeight().appear(2)) { sub = "recv" }
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Max), Arrangement.spacedBy(14.dp)) {
                            Tile(Icons.AutoMirrored.Outlined.Send, "Send Files", "Transfer files to another device.", Modifier.weight(1f).fillMaxHeight().appear(3)) { sub = "send" }
                            Tile(Icons.Outlined.QrCode2, "Scan QR", "Connect quickly using QR.", Modifier.weight(1f).fillMaxHeight().appear(4)) { scan() }
                        }
                        Sec("Nearby Devices", 28) { Scanning() }
                        NearbyList(net.peers, "Connect") { pick(it) }
                    }

                    "cast" -> {
                        Head("Cast Screen") { sub = null }
                        Sec("Nearby Devices", 0) { Scanning() }
                        NearbyList(net.peers, "Connect") { pick(it) }
                        Sec("Other ways to connect", 28)
                        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                            Btn("Scan QR", mod = Modifier.weight(1f)) { scan() }
                            Btn("Enter PIN", mod = Modifier.weight(1f)) { pinReq = PinReq(null) { q -> chosen(q) } }
                        }
                    }

                    "recv" -> {
                        Head("Receive Screen") { sub = null }
                        val payload = remember(net.code, net.name, net.port) { net.qrPayload() }
                        Column(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Tx("Ready to receive", 24, Medium, al = TextAlign.Center)
                            Spacer(Modifier.height(32.dp))
                            Qr(payload)
                            Tx(net.code.substring(0, 3) + " " + net.code.substring(3), 28, Medium, c.tx, Modifier.padding(top = 28.dp, bottom = 12.dp), ls = 4f)
                            Tx("Scan this QR code or enter the code on another Mirrox device.", 14, col = c.mu, mod = Modifier.widthIn(max = 280.dp), al = TextAlign.Center)
                            Tx("Keep Mirrox open. When another device casts its screen to this one, it appears here.", 13, col = c.mu, mod = Modifier.widthIn(max = 280.dp).padding(top = 16.dp), al = TextAlign.Center)
                        }
                    }

                    "conn" -> Column(Modifier.fillMaxWidth().padding(top = 96.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(Modifier.size(32.dp), color = c.ac, strokeWidth = 3.dp)
                        Tx("Connecting…", 18, Medium, c.tx, Modifier.padding(top = 20.dp, bottom = 4.dp))
                        Tx(castPeer?.name ?: "", 14, col = c.mu)
                    }

                    "active" -> {
                        Head("Connected")
                        Item(iconFor(castPeer?.type ?: ""), castPeer?.name ?: "", "Casting ${time()}" + if (Cast.paused) " • Paused" else "")
                        Tx(Cast.stats.ifEmpty { "Starting…" }, 12, col = c.mu, mod = Modifier.padding(bottom = 8.dp))
                        Row(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 20.dp), Arrangement.spacedBy(8.dp)) {
                            @Composable
                            fun Ctl(i: ImageVector, t: String, f: () -> Unit) =
                                Column(Modifier.weight(1f).tapBox(c.sf, Rad, 0.94f) { f() }.padding(vertical = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    Ic(i, c.tx); Spacer(Modifier.height(4.dp)); Tx(t, 12)
                                }
                            Ctl(if (Cast.paused) Icons.Outlined.PlayArrow else Icons.Outlined.Pause, if (Cast.paused) "Resume" else "Pause") { Cast.paused = !Cast.paused }
                            Ctl(Icons.Outlined.Tune, "Quality") { choice = SETS[1].second[0] }
                            Ctl(Icons.Outlined.StopCircle, "Stop") { CastService.stop(ctx); live = false; sub = null; tab = 0 }
                        }
                        Btn("Stop Casting", true, Modifier.fillMaxWidth()) { CastService.stop(ctx); live = false; sub = null; tab = 0 }
                        var det by remember { mutableStateOf(false) }
                        Sec("Connection Details", 28) { Tx(if (det) "Hide" else "Show", 14, Medium, c.ac, Modifier.clickable { det = !det }.padding(4.dp)) }
                        if (det) Column(Modifier.fillMaxWidth().box(c.sf).padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Tx("Address  ${castPeer?.host ?: "-"}:${castPeer?.port ?: "-"}", 13, col = c.mu)
                            Tx("Quality  ${st["q"]}  •  ${st["fps"]}  (changes apply to the next cast)", 13, col = c.mu)
                        }
                    }

                    "send" -> {
                        Head("Send Files") { sub = null }
                        val f = file
                        if (f == null) {
                            Btn("Select files", true, Modifier.fillMaxWidth()) { picker.launch("*/*") }
                            Tx("Choose a file, then pick a device.", 12, col = c.mu, mod = Modifier.padding(top = 12.dp).align(Alignment.CenterHorizontally))
                        } else {
                            Item(Icons.Outlined.Description, f.name, fmt(f.size))
                            val t = target
                            Row(
                                Modifier.fillMaxWidth().padding(bottom = 20.dp).tapBox(c.sf, Rad, 0.98f) { sub = "dest" }.padding(start = 16.dp, end = 12.dp, top = 10.dp, bottom = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Ic(if (t != null) iconFor(t.type) else Icons.Outlined.Devices); Spacer(Modifier.width(14.dp))
                                Column(Modifier.weight(1f)) { Tx(t?.name ?: "Choose device", 14, Medium); Tx("Destination device", 12, col = c.mu) }
                                Ic(Icons.Outlined.ChevronRight)
                            }
                            Btn("Send", true, Modifier.fillMaxWidth()) {
                                if (t == null) sub = "dest"
                                else if (net.canConnect(t)) startSend(t)
                                else pinReq = PinReq(t) { q -> startSend(q) }
                            }
                        }
                    }

                    "dest" -> {
                        Head("Select Device") { sub = "send" }
                        Sec("Nearby Devices", 0) { Scanning() }
                        NearbyList(net.peers, "Select") { pick(it) }
                        Sec("Other ways to connect", 28)
                        Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                            Btn("Scan QR", mod = Modifier.weight(1f)) { scan() }
                            Btn("Enter PIN", mod = Modifier.weight(1f)) { pinReq = PinReq(null) { q -> chosen(q) } }
                        }
                    }

                    "devices" -> {
                        Head("Devices")
                        Sec("Nearby", 0) { Scanning() }
                        NearbyList(net.peers, "Connect") { pick(it) }
                        val nearIds = net.peers.map { it.id }.toSet()
                        val recent = net.known.filter { it.id !in nearIds }.take(5)
                        Sec("Recent", 16)
                        if (recent.isEmpty()) Empty("Devices you connect to appear here.")
                        else recent.forEach { k -> Item(iconFor(k.type), k.name, "${typeLabel(k.type)} • ${ago(k.last)}") { Btn("Connect", small = true) { pick(k.toPeer()) } } }
                        Sec("Trusted", 16)
                        if (trusted.isEmpty()) Empty("Paired devices appear here.")
                        else trusted.forEach { k -> Item(iconFor(k.type), k.name, "${typeLabel(k.type)} • Always allowed") { Btn("Connect", small = true) { pick(k.toPeer()) } } }
                    }

                    "transfers" -> {
                        Head("Transfers")
                        val x = net.current
                        if (x != null) Column(Modifier.fillMaxWidth().padding(bottom = 16.dp).box(c.sf).padding(16.dp)) {
                            val frac = if (x.total > 0) (x.done.toFloat() / x.total).coerceIn(0f, 1f) else 1f
                            val p by animateFloatAsState(frac, tween(250), label = "progress")
                            Tx((if (x.sending) "Sending to " else "Receiving from ") + x.peer, 12, col = c.mu, mod = Modifier.padding(bottom = 4.dp))
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Tx(x.name, 14, Medium, mod = Modifier.weight(1f)); Tx("${(frac * 100).toInt()}%", 14)
                            }
                            LinearProgressIndicator(progress = { p }, Modifier.fillMaxWidth().padding(vertical = 12.dp).height(4.dp), color = c.ac, trackColor = c.tl)
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Tx("${fmt(x.done)} / ${fmt(x.total)}", 12, col = c.mu); Tx("${fmt(x.speed)}/s", 12, col = c.mu)
                            }
                            Btn("Cancel", mod = Modifier.padding(top = 12.dp), small = true) { net.cancel() }
                        }
                        Sec("Recent", 0)
                        if (net.history.isEmpty()) Empty("No transfers yet.")
                        else net.history.take(30).forEach { h ->
                            Item(if (h.sent) Icons.Outlined.FileUpload else Icons.Outlined.FileDownload, h.name, h.detail) { Tx(if (h.ok) "Completed" else "Incomplete", 12, col = c.mu) }
                        }
                    }

                    else -> {
                        Head("Settings", back = { tab = 0 })
                        SETS.forEachIndexed { si, (sec, rows) ->
                            Tx(sec, 18, Bold, c.ac, Modifier.appear(si).padding(top = if (si == 0) 0.dp else 24.dp, bottom = 10.dp))
                            Column(Modifier.fillMaxWidth().appear(si).box(c.sf, 20.dp)) {
                                rows.forEachIndexed { ri, r ->
                                    val v = when {
                                        r.k == "name" -> net.name
                                        r.k != null -> st[r.k]
                                        r.l == "Download Location" -> net.saveLocation
                                        r.l == "Trusted Devices" -> trustedText
                                        r.l == "Mirrox Version" -> appVer
                                        else -> r.v
                                    }
                                    Row(
                                        Modifier.fillMaxWidth().clickable {
                                            when {
                                                r.sw -> setSt(r.k!!, if (st[r.k] == "On") "Off" else "On")
                                                r.edit -> nameD = true
                                                r.k != null -> choice = r
                                                r.l == "Download Location" -> info = r.l to "Received files are saved to ${net.saveLocation}."
                                                r.l == "Trusted Devices" -> info = r.l to trustedInfo
                                                r.l == "Mirrox Version" -> info = r.l to "Mirrox $appVer"
                                                else -> info = r.l to (r.i ?: r.v ?: "")
                                            }
                                        }.padding(horizontal = 16.dp, vertical = 14.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(Modifier.size(28.dp), Alignment.Center) { if (r.ic != null) Ic(r.ic, c.ac, 26) else FpsIcon() }
                                        Spacer(Modifier.width(16.dp))
                                        Column(Modifier.weight(1f)) {
                                            Tx(r.l, 16, SemiBold)
                                            if (v != null) Tx(v, 14, col = c.mu)
                                        }
                                        if (r.sw) Switch(
                                            checked = st[r.k ?: ""] == "On", onCheckedChange = { setSt(r.k!!, if (it) "On" else "Off") },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = Color.White, checkedTrackColor = c.ac, checkedBorderColor = c.ac,
                                                uncheckedThumbColor = Color.White, uncheckedTrackColor = c.tl, uncheckedBorderColor = c.tl
                                            )
                                        ) else Ic(Icons.Outlined.ChevronRight, c.mu, 22)
                                    }
                                    if (ri < rows.lastIndex) HorizontalDivider(Modifier.padding(start = 60.dp), color = c.bd)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom navigation: Home | Devices | Transfers | Settings
        if (isDark) HorizontalDivider(color = c.bd)
        Row(
            Modifier.fillMaxWidth()
                .shadow(if (isDark) 0.dp else 10.dp, RectangleShape, ambientColor = Color(0x1A1F3A6E), spotColor = Color(0x261F3A6E))
                .background(c.sf).navigationBarsPadding().padding(start = 8.dp, end = 8.dp, top = 10.dp, bottom = 4.dp)
        ) {
            listOf(
                Triple("Home", Icons.Outlined.Home, 0), Triple("Devices", Icons.Outlined.Devices, 1),
                Triple("Transfers", Icons.Outlined.SwapHoriz, 2), Triple("Settings", Icons.Outlined.Settings, 3)
            ).forEach { (t, i, n) ->
                val on = tab == n
                val src = remember { MutableInteractionSource() }
                val tint by animateColorAsState(if (on) c.ac else c.mu, tween(220), label = "navTint")
                val pop by animateFloatAsState(if (on) 1.12f else 1f, spring(dampingRatio = 0.5f, stiffness = 400f), label = "navPop")
                val bar by animateDpAsState(if (on) 52.dp else 0.dp, spring(dampingRatio = 0.7f, stiffness = 500f), label = "navBar")
                Column(
                    Modifier.weight(1f).tapScale(src, 0.9f).clickable(src, null) { if (tab != n || sub != null) { tab = n; sub = null } },
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(Modifier.graphicsLayer { scaleX = pop; scaleY = pop }) { Ic(i, tint, 28) }
                    Spacer(Modifier.height(2.dp))
                    Tx(t, 13, if (on) SemiBold else Medium, tint)
                    Spacer(Modifier.height(6.dp))
                    Box(Modifier.size(width = bar, height = 3.dp).clip(RoundedCornerShape(2.dp)).background(c.ac))
                }
            }
        }
    }

    // ------------------------------------------------------------ Dialogs
    Cast.viewer?.let { ViewerScreen(it) }
    capFor?.let { p ->
        Dlg("Allow screen capture?", { capFor = null },
            confirm = { TBtn("Start now") { capFor = null; castPeer = p; sub = "conn" } },
            cancel = { TBtn("Cancel") { capFor = null } }
        ) { Tx("Mirrox will start capturing everything shown on your screen and share it with ${p.name}.", 14, col = c.mu) }
    }
    info?.let { (t, m) ->
        Dlg(t, { info = null }, confirm = { TBtn("OK") { info = null } }) { Tx(m, 14, col = c.mu) }
    }
    choice?.let { r ->
        val k = r.k ?: ""
        Dlg(r.l, { choice = null }, cancel = { TBtn("Cancel") { choice = null } }) {
            Column {
                r.o.forEach { o ->
                    Row(Modifier.fillMaxWidth().clickable { setSt(k, o); choice = null }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(st[k] == o, { setSt(k, o); choice = null }, colors = RadioButtonDefaults.colors(selectedColor = c.ac, unselectedColor = c.mu))
                        Tx(o, 14)
                    }
                }
            }
        }
    }
    pinReq?.let { rq ->
        var pin by remember { mutableStateOf("") }
        var addr by remember { mutableStateOf("") }
        var err by remember { mutableStateOf<String?>(null) }
        var busy by remember { mutableStateOf(false) }
        Dlg("Enter PIN", { if (!busy) pinReq = null },
            confirm = {
                TBtn(if (busy) "Connecting…" else "Connect") {
                    if (!busy && pin.length == 6) {
                        val peer = rq.peer
                        val dest: Pair<String, Int>? = if (peer != null) peer.host to peer.port else parseAddr(addr)
                        if (dest == null) err = "Enter the device address, for example 192.168.1.5"
                        else {
                            busy = true; err = null
                            net.pair(dest.first, dest.second, pin, peer?.id) { r ->
                                busy = false
                                r.onSuccess { p -> pinReq = null; rq.then(p) }.onFailure { e -> err = errText(e) }
                            }
                        }
                    }
                }
            },
            cancel = { TBtn("Cancel") { if (!busy) pinReq = null } }
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                val who = rq.peer
                Tx(if (who != null) "Enter the 6-digit code shown on ${who.name}." else "Enter the address and 6-digit code shown on the other device.", 14, col = c.mu)
                if (who == null) OutlinedTextField(addr, { addr = it.trim() }, placeholder = { Text("Address, e.g. 192.168.1.5") }, singleLine = true, shape = RoundedCornerShape(Rad))
                OutlinedTextField(
                    pin, { if (it.length <= 6) pin = it.filter { ch -> ch.isDigit() } },
                    placeholder = { Text("6-digit code") }, singleLine = true, shape = RoundedCornerShape(Rad),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
                err?.let { Tx(it, 13) }
            }
        }
    }
    if (nameD) {
        var nm by remember { mutableStateOf(net.name) }
        Dlg("Device Name", { nameD = false },
            confirm = { TBtn("Save") { if (nm.isNotBlank()) net.rename(nm); nameD = false } },
            cancel = { TBtn("Cancel") { nameD = false } }
        ) { OutlinedTextField(nm, { nm = it }, singleLine = true, shape = RoundedCornerShape(Rad)) }
    }
}
