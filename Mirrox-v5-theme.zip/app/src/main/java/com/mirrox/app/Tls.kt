package com.mirrox.app

import android.content.SharedPreferences
import android.util.Base64
import java.io.ByteArrayInputStream
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.Signature
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLServerSocketFactory
import javax.net.ssl.SSLSocket
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

/**
 * TLS for Mirrox (see PROTOCOL.md, v2).
 *
 * Every device owns one long-lived self-signed certificate. Nobody validates it against a CA; instead
 * devices PIN the SHA-256 fingerprint of the certificate: it comes from the QR code, or is remembered
 * from the first PIN pairing.
 */
object Tls {
    class Identity(val cert: X509Certificate, val key: PrivateKey) {
        val fp: String = fingerprint(cert.encoded)
    }

    fun fingerprint(der: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(der).joinToString("") { "%02x".format(it) }

    fun protocols(supported: Array<String>): Array<String> =
        supported.filter { it == "TLSv1.2" || it == "TLSv1.3" }.toTypedArray()

    // ------------------------------------------------------------ identity
    fun loadOrCreate(prefs: SharedPreferences): Identity {
        val c = prefs.getString("tls_cert", null)
        val k = prefs.getString("tls_key", null)
        if (c != null && k != null) {
            try {
                val cert = CertificateFactory.getInstance("X.509")
                    .generateCertificate(ByteArrayInputStream(Base64.decode(c, Base64.NO_WRAP))) as X509Certificate
                val key = KeyFactory.getInstance("EC").generatePrivate(PKCS8EncodedKeySpec(Base64.decode(k, Base64.NO_WRAP)))
                return Identity(cert, key)
            } catch (_: Exception) {
                // damaged: fall through and make a new identity
            }
        }
        val id = create()
        prefs.edit()
            .putString("tls_cert", Base64.encodeToString(id.cert.encoded, Base64.NO_WRAP))
            .putString("tls_key", Base64.encodeToString(id.key.encoded, Base64.NO_WRAP))
            .commit()
        return id
    }

    // Minimal DER writer: enough to build one self-signed X.509 v3 certificate (no extensions).
    private fun der(tag: Int, body: ByteArray): ByteArray {
        val n = body.size
        val len = when {
            n < 0x80 -> byteArrayOf(n.toByte())
            n < 0x100 -> byteArrayOf(0x81.toByte(), n.toByte())
            else -> byteArrayOf(0x82.toByte(), (n shr 8).toByte(), n.toByte())
        }
        return byteArrayOf(tag.toByte()) + len + body
    }

    private fun seq(vararg parts: ByteArray): ByteArray = der(0x30, parts.fold(ByteArray(0)) { a, b -> a + b })

    private fun utcTime(ms: Long): ByteArray {
        val f = SimpleDateFormat("yyMMddHHmmss'Z'", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return der(0x17, f.format(Date(ms)).toByteArray(Charsets.US_ASCII))
    }

    private fun create(): Identity {
        val kpg = KeyPairGenerator.getInstance("EC")
        kpg.initialize(ECGenParameterSpec("secp256r1"))
        val kp = kpg.generateKeyPair()

        // OID 1.2.840.10045.4.3.2 (ecdsa-with-SHA256)
        val sigAlg = seq(byteArrayOf(0x06, 0x08, 0x2A, 0x86.toByte(), 0x48, 0xCE.toByte(), 0x3D, 0x04, 0x03, 0x02))
        // Name: CN=Mirrox  (OID 2.5.4.3, UTF8String)
        val name = seq(der(0x31, seq(byteArrayOf(0x06, 0x03, 0x55, 0x04, 0x03), der(0x0C, "Mirrox".toByteArray(Charsets.UTF_8)))))
        val serial = ByteArray(8).also { SecureRandom().nextBytes(it) }
        serial[0] = ((serial[0].toInt() and 0x7F) or 0x01).toByte() // positive, no leading zero byte
        val now = System.currentTimeMillis()
        val day = 24L * 3600 * 1000

        val tbs = seq(
            der(0xA0, der(0x02, byteArrayOf(2))),            // version: v3
            der(0x02, serial),
            sigAlg,
            name,
            seq(utcTime(now - day), utcTime(now + 7300 * day)), // about 20 years (ends before 2050)
            name,
            kp.public.encoded                                   // SubjectPublicKeyInfo
        )
        val sig = Signature.getInstance("SHA256withECDSA").run {
            initSign(kp.private)
            update(tbs)
            sign()
        }
        val certDer = seq(tbs, sigAlg, der(0x03, byteArrayOf(0) + sig))
        val cert = CertificateFactory.getInstance("X.509").generateCertificate(ByteArrayInputStream(certDer)) as X509Certificate
        return Identity(cert, kp.private)
    }

    // ------------------------------------------------------------ sockets
    fun serverFactory(id: Identity): SSLServerSocketFactory {
        val pw = "mirrox".toCharArray()
        val ks = KeyStore.getInstance("PKCS12")
        ks.load(null, null)
        ks.setKeyEntry("id", id.key, pw, arrayOf(id.cert))
        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(ks, pw)
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(kmf.keyManagers, null, SecureRandom())
        return ctx.serverSocketFactory
    }

    // No CA checks: the caller compares the peer certificate fingerprint (pinning) right after connecting
    // and sends nothing secret before that.
    private val acceptAny: Array<TrustManager> = arrayOf(object : X509TrustManager {
        override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
    })

    private val clientFactory by lazy {
        val ctx = SSLContext.getInstance("TLS")
        ctx.init(null, acceptAny, SecureRandom())
        ctx.socketFactory
    }

    /** Opens a TLS connection and finishes the handshake. The caller must check [peerFingerprint]. */
    fun connect(host: String, port: Int, timeoutMs: Int): SSLSocket {
        val raw = Socket()
        try {
            raw.connect(InetSocketAddress(InetAddress.getByName(host), port), timeoutMs)
            raw.soTimeout = 30_000
            val s = clientFactory.createSocket(raw, host, port, true) as SSLSocket
            s.enabledProtocols = protocols(s.supportedProtocols)
            s.startHandshake()
            return s
        } catch (e: Exception) {
            try { raw.close() } catch (_: Exception) {}
            throw e
        }
    }

    fun peerFingerprint(s: SSLSocket): String = fingerprint(s.session.peerCertificates[0].encoded)
}
