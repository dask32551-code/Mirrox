"""Screen cast tests: a fake phone speaks the real protocol over TLS and sends real H.264 streams.

Decoding needs PyAV or an `ffmpeg` binary; those tests are skipped when neither exists.
"""
import re
import shutil
import socket
import struct
import tempfile
import threading
import time
import unittest
from pathlib import Path

import cast_fixture
import mirrox_cast as c
import mirrox_pc as m


# ----------------------------------------------------------------------------- helpers
def split_aus(stream):
    """Annex-B stream -> (config, [(is_key, access unit)]), the way Android's MediaCodec hands it out:
    SPS+PPS come separately, key frames carry no parameter sets."""
    starts = [x.start() for x in re.finditer(b"\x00\x00\x01", stream)]
    nals = []
    for i, s in enumerate(starts):
        e = starts[i + 1] if i + 1 < len(starts) else len(stream)
        body = stream[s:e].rstrip(b"\x00") if i + 1 < len(starts) else stream[s:e]
        nals.append((stream[s + 3] & 31, b"\x00\x00\x00\x01" + body[3:]))
    config = b"".join(n for t, n in nals if t in (7, 8))
    aus, cur = [], []
    for t, n in nals:
        if t in (7, 8):
            continue
        cur.append((t, n))
        if t in (1, 5):
            aus.append((t == 5, b"".join(x for _, x in cur)))
            cur = []
    return config, aus


def config_payload(w, h, config):
    return struct.pack(">HH", w, h) + config


def send_packet(sock, typ, data=b"", pts=0):
    sock.sendall(c.HDR.pack(typ, len(data), pts) + data)


def wait_for(cond, timeout=5.0):
    end = time.time() + timeout
    while time.time() < end:
        if cond():
            return True
        time.sleep(0.01)
    return cond()


def available_decoders():
    out = []
    try:
        import av  # noqa: F401
        out.append("pyav")
    except ImportError:
        pass
    if shutil.which("ffmpeg"):
        out.append("ffmpeg")
    return out


def nearest(rgb):
    palette = {"red": (255, 0, 0), "green": (0, 255, 0), "blue": (0, 0, 255), "white": (255, 255, 255),
               "magenta": (255, 0, 255), "yellow": (255, 255, 0)}
    return min(palette, key=lambda k: sum((a - b) ** 2 for a, b in zip(rgb, palette[k])))


class CastBase(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.events = []
        self.rx = m.Config(str(Path(self.tmp.name) / "RX"), "RX", str(Path(self.tmp.name) / "RX" / "R"))
        self.tx = m.Config(str(Path(self.tmp.name) / "TX"), "TX", str(Path(self.tmp.name) / "TX" / "R"))
        self.server = m.Server(self.rx, 0, lambda *a: self.events.append(a)).start()

    def tearDown(self):
        self.server.stop()
        self.tmp.cleanup()

    def session(self, timeout=5.0):
        self.assertTrue(wait_for(lambda: any(e[0] == "cast" for e in self.events), timeout), "no cast session")
        return [e for e in self.events if e[0] == "cast"][-1][1]

    def phone(self, w=64, h=64, fps=30, codec="h264", **extra):
        """Connect like the Android app does; returns (socket, reply to cast_start)."""
        s, _ = m.connect(self.tx, "127.0.0.1", self.server.port,
                         peer_id=self.rx.id if self.tx.known.get(self.rx.id, {}).get("token") else None,
                         code=None if self.tx.known.get(self.rx.id, {}).get("token") else self.server.code)
        s.settimeout(5)
        msg = {"t": "cast_start", "codec": codec, "w": w, "h": h, "fps": fps}
        msg.update(extra)
        m.send_msg(s, msg)
        return s, m.recv_msg(s)


# ----------------------------------------------------------------------------- protocol level
class CastProtocolTests(CastBase):
    def test_bad_requests_are_refused(self):
        for kw, err in (({"codec": "vp9"}, "unsupported_codec"), ({"w": 0}, "bad_size"),
                        ({"h": 100000}, "bad_size"), ({"w": True}, "bad_size")):
            s, reply = self.phone(**kw)
            self.assertEqual(reply, {"t": "err", "msg": err}, kw)
            s.close()
        self.assertFalse(any(e[0] == "cast" for e in self.events))

    def test_headless_server_refuses(self):
        self.server.accept_cast = False
        s, reply = self.phone()
        self.assertEqual(reply, {"t": "err", "msg": "no_display"})
        s.close()

    def test_no_decoder_is_reported(self):
        self.server.decoder_factory = lambda on_frame: None
        s, reply = self.phone()
        self.assertEqual(reply, {"t": "err", "msg": "no_decoder"})
        s.close()
        # and the PC is not stuck "busy" afterwards
        self.server.decoder_factory = lambda on_frame: FakeDecoder()
        s, reply = self.phone()
        self.assertEqual(reply, {"t": "cast_ok"})
        send_packet(s, c.CP_END)
        s.close()

    def test_only_one_cast_at_a_time(self):
        self.server.decoder_factory = lambda on_frame: FakeDecoder()
        s1, r1 = self.phone()
        self.assertEqual(r1, {"t": "cast_ok"})
        self.session()
        s2, r2 = self.phone()
        self.assertEqual(r2, {"t": "err", "msg": "cast_busy"})
        s2.close()
        send_packet(s1, c.CP_END)
        s1.close()
        self.assertTrue(wait_for(lambda: any(e[0] == "cast_end" for e in self.events)))
        s3, r3 = self.phone()
        self.assertEqual(r3, {"t": "cast_ok"})
        send_packet(s3, c.CP_END)
        s3.close()

    def test_cast_needs_authentication(self):
        s = socket.create_connection(("127.0.0.1", self.server.port))
        import ssl
        ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        s = ctx.wrap_socket(s)
        s.settimeout(3)
        m.send_msg(s, {"t": "cast_start", "codec": "h264", "w": 64, "h": 64, "fps": 30})
        reply = m.recv_msg(s)
        self.assertEqual(reply["t"], "err")
        self.assertNotEqual(reply["msg"], "cast_ok")
        s.close()
        self.assertFalse(any(e[0] == "cast" for e in self.events))

    def test_oversize_and_garbage_packets_end_the_cast(self):
        self.server.decoder_factory = lambda on_frame: FakeDecoder()
        s, r = self.phone()
        self.assertEqual(r["t"], "cast_ok")
        sess = self.session()
        s.sendall(c.HDR.pack(c.CP_KEY, c.MAX_PKT + 1, 0))
        self.assertTrue(sess.finished.wait(5))
        self.assertIn("too large", sess.error)
        s.close()

    def test_pause_resume_and_ping(self):
        self.server.decoder_factory = lambda on_frame: FakeDecoder()
        s, _ = self.phone()
        sess = self.session()
        send_packet(s, c.CP_PING)
        send_packet(s, c.CP_PAUSE)
        self.assertTrue(wait_for(lambda: sess.paused))
        send_packet(s, c.CP_RESUME)
        self.assertTrue(wait_for(lambda: not sess.paused))
        send_packet(s, 99, b"from the future")        # unknown packet types are ignored
        send_packet(s, c.CP_END)
        self.assertTrue(sess.finished.wait(5))
        self.assertIsNone(sess.error)
        s.close()

    def test_window_stop_closes_connection(self):
        self.server.decoder_factory = lambda on_frame: FakeDecoder()
        s, _ = self.phone()
        sess = self.session()
        sess.stop()
        self.assertTrue(sess.finished.wait(5))
        s.settimeout(0.2)

        def phone_notices():
            try:
                send_packet(s, c.CP_PING)
                return False
            except OSError:
                return True
        self.assertTrue(wait_for(phone_notices, 5), "phone should see the connection close")
        s.close()

    def test_phone_vanishing_ends_cast_with_error(self):
        self.server.decoder_factory = lambda on_frame: FakeDecoder()
        s, _ = self.phone()
        sess = self.session()
        s.close()                                      # no CP_END: Wi-Fi gone, app killed ...
        self.assertTrue(sess.finished.wait(5))
        self.assertTrue(sess.error)


class FakeDecoder:
    name = "fake"

    def __init__(self, fail_keys=0, delay=0.0):
        self.calls, self.fail_keys, self.delay = [], fail_keys, delay

    def decode(self, data, stream_size, view_size):
        if self.delay:
            time.sleep(self.delay)
        self.calls.append((data, stream_size))

    def close(self):
        pass


# ----------------------------------------------------------------------------- queue behaviour
class QueueTests(unittest.TestCase):
    def make(self):
        return c.CastSession({"w": 64, "h": 64, "fps": 30}, "T", lambda on_frame: FakeDecoder())

    def test_deltas_before_first_key_are_ignored(self):
        s = self.make()
        s.feed(c.CP_DELTA, 0, b"d")
        s.feed(c.CP_CONFIG, 0, struct.pack(">HH", 64, 64) + b"c")
        s.feed(c.CP_KEY, 0, b"k")
        s.feed(c.CP_DELTA, 0, b"d")
        self.assertEqual([p[0] for p in s._q], [c.CP_CONFIG, c.CP_KEY, c.CP_DELTA])

    def test_overload_keeps_latest_key_frame(self):
        s = self.make()
        s.feed(c.CP_CONFIG, 0, struct.pack(">HH", 64, 64) + b"c")
        s.feed(c.CP_KEY, 0, b"k1")
        for _ in range(10):
            s.feed(c.CP_DELTA, 0, b"d")
        s.feed(c.CP_CONFIG, 0, struct.pack(">HH", 64, 64) + b"c")
        s.feed(c.CP_KEY, 0, b"k2")
        for _ in range(32):                      # 14 + 32 = 46 > MAX_QUEUE: trim once
            s.feed(c.CP_DELTA, 0, b"d")
        types = [p[0] for p in s._q]
        self.assertLessEqual(len(types), c.MAX_QUEUE)
        self.assertEqual(types[:2], [c.CP_CONFIG, c.CP_KEY])
        self.assertEqual(s._q[1][2], b"k2", "must restart from the newest key frame")

    def test_overload_without_older_data_waits_for_next_key(self):
        s = self.make()
        s.feed(c.CP_CONFIG, 0, struct.pack(">HH", 64, 64) + b"c")
        s.feed(c.CP_KEY, 0, b"k")
        for _ in range(c.MAX_QUEUE + 5):
            s.feed(c.CP_DELTA, 0, b"d")
        self.assertEqual([p[0] for p in s._q], [c.CP_CONFIG])
        s.feed(c.CP_DELTA, 0, b"d")
        self.assertEqual(len(s._q), 1, "deltas are dropped until a key frame arrives")
        s.feed(c.CP_KEY, 0, b"k")
        self.assertEqual([p[0] for p in s._q], [c.CP_CONFIG, c.CP_KEY])

    def test_decoder_gets_parameter_sets_and_waits_for_key_after_error(self):
        class Flaky(FakeDecoder):
            def decode(self, data, stream_size, view_size):
                super().decode(data, stream_size, view_size)
                if len(self.calls) == 1:
                    raise RuntimeError("corrupt")
        dec = Flaky()
        s = c.CastSession({"w": 64, "h": 64, "fps": 30}, "T", lambda on_frame: dec)
        t = threading.Thread(target=s._decode_loop, daemon=True)
        t.start()
        cfg = struct.pack(">HH", 64, 64) + b"SPSPPS"
        for typ, data in ((c.CP_CONFIG, cfg), (c.CP_KEY, b"K1"), (c.CP_DELTA, b"D1"), (c.CP_DELTA, b"D2"),
                          (c.CP_KEY, b"K2"), (c.CP_DELTA, b"D3")):
            s.feed(typ, 0, data)
        self.assertTrue(wait_for(lambda: len(dec.calls) >= 3))
        s.stop()
        t.join(2)
        self.assertEqual([d for d, _ in dec.calls], [b"SPSPPSK1", b"SPSPPSK2", b"D3"])
        self.assertEqual(s.decode_errors, 1)


# ----------------------------------------------------------------------------- real decoding
class DecodeTests(CastBase):
    def run_stream(self, decoder, parts):
        """parts: list of (w, h, stream). Returns the decoded frames in order."""
        frames = []

        def factory(on_frame):
            def hook(img):
                frames.append(img.copy())
                on_frame(img)
            return c.make_decoder(hook, prefer=decoder)
        self.server.decoder_factory = factory
        w0, h0, _ = parts[0]
        s, reply = self.phone(w=w0, h=h0)
        self.assertEqual(reply, {"t": "cast_ok"})
        sess = self.session()
        pts = 0
        for w, h, stream in parts:
            config, aus = split_aus(stream)
            send_packet(s, c.CP_CONFIG, config_payload(w, h, config))
            for is_key, au in aus:
                if is_key:
                    send_packet(s, c.CP_CONFIG, config_payload(w, h, config))
                send_packet(s, c.CP_KEY if is_key else c.CP_DELTA, au, pts)
                pts += 100000
                time.sleep(0.01)
        send_packet(s, c.CP_END)
        self.assertTrue(sess.finished.wait(10))
        s.close()
        self.assertIsNone(sess.error)
        # the ffmpeg fallback delivers its last frames from a reader thread after the cast ended
        total = sum(len(split_aus(st)[1]) for _, _, st in parts)
        wait_for(lambda: len(frames) >= total - 1, 15)
        return sess, frames

    def test_real_h264_decodes_with_correct_colours(self):
        names = available_decoders()
        if not names:
            self.skipTest("neither PyAV nor ffmpeg available")
        for name in names:
            with self.subTest(decoder=name):
                self.events.clear()
                sess, frames = self.run_stream(name, [(64, 64, cast_fixture.A)])
                # ffmpeg's raw demuxer holds back one frame; PyAV decodes every frame
                self.assertGreaterEqual(len(frames), 12 if name == "pyav" else 11)
                self.assertTrue(all(f.size == (64, 64) for f in frames))
                seen = []
                for f in frames:
                    col = nearest(f.getpixel((32, 32)))
                    if not seen or seen[-1] != col:
                        seen.append(col)
                self.assertEqual(seen, ["red", "green", "blue", "white"][:len(seen)])
                self.assertGreaterEqual(len(seen), 3)
                self.assertEqual(sess.decode_errors, 0)
                self.assertTrue(sess.frames >= len(frames))

    def test_orientation_change_switches_resolution(self):
        names = available_decoders()
        if not names:
            self.skipTest("neither PyAV nor ffmpeg available")
        for name in names:
            with self.subTest(decoder=name):
                self.events.clear()
                sess, frames = self.run_stream(name, [(64, 64, cast_fixture.A), (96, 48, cast_fixture.B)])
                sizes = [f.size for f in frames]
                self.assertIn((64, 64), sizes)
                self.assertIn((96, 48), sizes)
                self.assertLess(sizes.index((64, 64)), sizes.index((96, 48)))
                self.assertEqual(sess.size, (96, 48))
                colours = {nearest(f.getpixel((48, 24))) for f in frames if f.size == (96, 48)}
                self.assertLessEqual(colours, {"magenta", "yellow"})
                self.assertIn("magenta", colours)
                if name == "pyav":      # the ffmpeg fallback may still be holding back its last frames
                    self.assertIn("yellow", colours)

    def test_view_size_scales_in_decoder(self):
        if "pyav" not in available_decoders():
            self.skipTest("PyAV only: ffmpeg fallback always decodes at stream size")
        frames = []
        self.server.decoder_factory = lambda on_frame: c.PyAVDecoder(lambda img: (frames.append(img), on_frame(img)))
        s, _ = self.phone()
        sess = self.session()
        sess.view_size = (32, 32)
        config, aus = split_aus(cast_fixture.A)
        send_packet(s, c.CP_CONFIG, config_payload(64, 64, config))
        for is_key, au in aus[:4]:
            send_packet(s, c.CP_KEY if is_key else c.CP_DELTA, au)
        send_packet(s, c.CP_END)
        self.assertTrue(sess.finished.wait(5))
        s.close()
        self.assertTrue(frames and all(f.size == (32, 32) for f in frames))


class FixtureTests(unittest.TestCase):
    def test_fixture_streams_look_like_mediacodec_output(self):
        for stream, n in ((cast_fixture.A, 12), (cast_fixture.B, 6)):
            config, aus = split_aus(stream)
            self.assertEqual(len(aus), n)
            self.assertTrue(config.startswith(b"\x00\x00\x00\x01"))
            self.assertTrue(aus[0][0], "first access unit must be a key frame")
            for _, au in aus:
                self.assertNotIn(b"\x00\x00\x00\x01\x67", au, "no SPS inside access units")


if __name__ == "__main__":
    unittest.main()
