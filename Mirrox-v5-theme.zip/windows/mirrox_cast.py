"""Screen cast receiver for Mirrox (see ../PROTOCOL.md, "Screen cast").

The phone sends H.264 (Annex-B) access units over the already authenticated TLS connection. This module
reads them, decodes them on a separate thread and hands the newest picture to the window.

Decoders: PyAV (`pip install av`, bundled in the .exe) is preferred; an `ffmpeg` binary on PATH is the fallback.
"""
import collections
import os
import shutil
import socket
import struct
import subprocess
import threading
import time

# packet types (after the "cast_ok" reply, the phone -> PC direction is a stream of these packets)
CP_CONFIG = 1   # payload: u16 width, u16 height, then SPS+PPS in Annex-B form
CP_KEY = 2      # one H.264 access unit that starts with an IDR frame
CP_DELTA = 3    # one H.264 access unit (P frame)
CP_PAUSE = 4    # sender paused, no payload
CP_RESUME = 5
CP_END = 6      # sender stopped on purpose
CP_PING = 7     # keep-alive, sent when nothing else is
HDR = struct.Struct(">BIQ")   # type, payload length, presentation time in microseconds
MAX_PKT = 16 * 1024 * 1024
MAX_QUEUE = 45                # packets waiting for the decoder; more than this means we are too slow
MIN_DIM, MAX_DIM = 16, 8192


class NoDecoder(Exception):
    pass


def parse_start(msg):
    """Validate a `cast_start` message. Returns (info, None) or (None, error_code)."""
    if msg.get("codec") != "h264":
        return None, "unsupported_codec"
    out = {}
    for k in ("w", "h"):
        v = msg.get(k)
        if not isinstance(v, int) or isinstance(v, bool) or not MIN_DIM <= v <= MAX_DIM:
            return None, "bad_size"
        out[k] = v
    fps = msg.get("fps")
    out["fps"] = fps if isinstance(fps, int) and not isinstance(fps, bool) and 1 <= fps <= 240 else 30
    return out, None


def recv_exact(sock, n):
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(min(n - len(buf), 256 * 1024))
        if not chunk:
            raise ConnectionError("connection closed")
        buf += chunk
    return bytes(buf)


# ----------------------------------------------------------------------------- decoders
class PyAVDecoder:
    """Decodes one access unit per call. Each packet is a whole AU, so the parser (and its extra frame of
    delay) is bypassed."""
    name = "pyav"

    def __init__(self, on_frame):
        import av
        self._av = av
        self.on_frame = on_frame
        self.ctx = av.CodecContext.create("h264", "r")
        for attr, value in (("thread_type", "SLICE"), ("thread_count", 1)):
            try:
                setattr(self.ctx, attr, value)
            except Exception:
                pass
        try:
            self.ctx.options = {"flags": "low_delay"}
        except Exception:
            pass

    def decode(self, data, stream_size, view_size):
        for frame in self.ctx.decode(self._av.Packet(data)):
            if view_size:
                self.on_frame(frame.to_image(width=view_size[0], height=view_size[1]))
            else:
                self.on_frame(frame.to_image())

    def close(self):
        pass


class FFmpegPipeDecoder:
    """Fallback: pipes the stream through `ffmpeg` and reads raw RGB frames back."""
    name = "ffmpeg"

    def __init__(self, on_frame, exe):
        self.exe, self.on_frame = exe, on_frame
        self.proc, self.size = None, None

    def _start(self, w, h):
        self.close()
        # (-fflags nobuffer drops frames with piped input, so it is not used; the raw h264 reader still
        # holds back about two frames)
        cmd = [self.exe, "-loglevel", "error", "-threads", "1", "-flags", "low_delay",
               "-probesize", "32", "-analyzeduration", "0", "-f", "h264", "-i", "pipe:0", "-an",
               "-vf", f"scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1"]
        kw = {"creationflags": 0x08000000} if os.name == "nt" else {}   # no console window
        self.proc = subprocess.Popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                     stderr=subprocess.DEVNULL, **kw)
        self.size = (w, h)
        threading.Thread(target=self._read, args=(self.proc, w, h), daemon=True).start()

    def _read(self, proc, w, h):
        from PIL import Image
        n = w * h * 3
        while True:
            buf = bytearray()
            while len(buf) < n:
                chunk = proc.stdout.read(n - len(buf))
                if not chunk:
                    return
                buf += chunk
            self.on_frame(Image.frombuffer("RGB", (w, h), bytes(buf), "raw", "RGB", 0, 1))

    def decode(self, data, stream_size, view_size):
        if self.proc is None or self.size != stream_size or self.proc.poll() is not None:
            self._start(*stream_size)
        self.proc.stdin.write(data)
        self.proc.stdin.flush()

    def close(self):
        p, self.proc = self.proc, None
        if p is None:
            return
        for f in (p.stdin,):
            try:
                f.close()
            except OSError:
                pass
        try:
            p.wait(timeout=2)
        except subprocess.TimeoutExpired:
            p.kill()


def make_decoder(on_frame, prefer=None):
    """PyAV if installed, otherwise ffmpeg from PATH, otherwise None."""
    prefer = (prefer or os.environ.get("MIRROX_DECODER") or "").lower()
    if prefer != "ffmpeg":
        try:
            return PyAVDecoder(on_frame)
        except Exception:
            if prefer == "pyav":
                return None
    exe = shutil.which("ffmpeg")
    return FFmpegPipeDecoder(on_frame, exe) if exe else None


# ----------------------------------------------------------------------------- session
class CastSession:
    """One incoming screen cast. `run(conn)` blocks (network thread); the window calls `take()` and `stop()`."""

    def __init__(self, info, peer_name, decoder_factory=None):
        self.peer = peer_name
        self.size = (info["w"], info["h"])    # follows CONFIG packets (the phone changed orientation)
        self.fps = info["fps"]
        self.view_size = None                 # set by the window: decode straight to this size
        self.paused = False
        self.error = None
        self.finished = threading.Event()
        self.frames = 0
        self.bytes_in = 0
        self.decode_errors = 0
        self._latest, self._version = None, 0
        self._stamps = collections.deque(maxlen=90)
        self._lock = threading.Lock()
        self._cv = threading.Condition()
        self._q = collections.deque()
        self._wait_key = True
        self._stopping = False
        self._conn = None
        self._thread = None
        self.decoder = (decoder_factory or make_decoder)(self._on_frame)
        if self.decoder is None:
            raise NoDecoder()

    # ---- window side
    def take(self, seen):
        """(image, version) if there is a picture newer than `seen`, else None."""
        with self._lock:
            if self._version == seen or self._latest is None:
                return None
            return self._latest, self._version

    def fps_now(self):
        with self._lock:
            now = time.monotonic()
            recent = [t for t in self._stamps if now - t <= 2.0]
        return len(recent) / 2.0 if recent else 0.0

    def stop(self):
        """Stop the cast (any thread). Closing the connection is also how the phone learns about it."""
        with self._cv:
            self._stopping = True
            self._cv.notify_all()
        conn = self._conn
        if conn is not None:
            try:
                conn.shutdown(socket.SHUT_RDWR)
            except (OSError, ValueError, AttributeError):
                pass

    # ---- decoder callback (any thread)
    def _on_frame(self, img):
        with self._lock:
            self._latest = img
            self._version += 1
            self.frames += 1
            self._stamps.append(time.monotonic())

    # ---- network side
    def run(self, conn):
        self._conn = conn
        self._thread = threading.Thread(target=self._decode_loop, daemon=True)
        self._thread.start()
        try:
            while not self._stopping:
                typ, n, pts = HDR.unpack(recv_exact(conn, HDR.size))
                if n > MAX_PKT:
                    raise ConnectionError("packet too large")
                data = recv_exact(conn, n) if n else b""
                self.bytes_in += HDR.size + n
                if typ == CP_END:
                    break
                self.feed(typ, pts, data)
        except (OSError, ConnectionError, ValueError, AttributeError, struct.error) as e:
            if not self._stopping:
                self.error = str(e) or e.__class__.__name__
        finally:
            self.finish()

    def feed(self, typ, pts, data):
        if typ == CP_PAUSE:
            self.paused = True
            return
        if typ == CP_RESUME:
            self.paused = False
            return
        if typ not in (CP_CONFIG, CP_KEY, CP_DELTA):
            return                              # CP_PING and anything newer than us
        with self._cv:
            if typ == CP_DELTA and self._wait_key:
                return
            if typ == CP_KEY:
                self._wait_key = False
            self._q.append((typ, pts, data))
            if len(self._q) > MAX_QUEUE:
                self._trim()
            self._cv.notify()

    def _trim(self):
        """Decoder too slow: keep only what starts at the newest key frame (called with the lock held)."""
        items = list(self._q)
        keys = [i for i, p in enumerate(items) if p[0] == CP_KEY]
        if keys:
            start = keys[-1]
            if start > 0 and items[start - 1][0] == CP_CONFIG:
                start -= 1
            if start > 0 and len(items) - start <= MAX_QUEUE:
                self._q = collections.deque(items[start:])
                return
        # Nothing older to throw away: drop everything and wait for the next key frame.
        self._q = collections.deque([p for p in items if p[0] == CP_CONFIG][-1:])
        self._wait_key = True

    def _decode_loop(self):
        cfg, have_key = b"", False
        while True:
            with self._cv:
                while not self._q and not self._stopping:
                    self._cv.wait(0.5)
                if self._stopping:
                    return
                typ, pts, data = self._q.popleft()
            try:
                if typ == CP_CONFIG:
                    if len(data) > 4:
                        w, h = struct.unpack(">HH", data[:4])
                        if MIN_DIM <= w <= MAX_DIM and MIN_DIM <= h <= MAX_DIM:
                            self.size = (w, h)
                            cfg = data[4:]
                elif typ == CP_KEY:
                    self.decoder.decode(cfg + data, self.size, self.view_size)
                    have_key = True
                    self.paused = False
                elif typ == CP_DELTA and have_key:
                    self.decoder.decode(data, self.size, self.view_size)
                    self.paused = False
            except Exception:
                self.decode_errors += 1
                have_key = False                # wait for the next key frame before decoding again
                if self._stopping:
                    return

    def finish(self):
        with self._cv:
            self._stopping = True
            self._cv.notify_all()
        if self._thread is not None:
            self._thread.join(3)
        try:
            self.decoder.close()
        except Exception:
            pass
        self.finished.set()
