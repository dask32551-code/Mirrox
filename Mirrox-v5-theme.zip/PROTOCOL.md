# Mirrox protocol v2

Android and Windows speak the same small protocol over the local network. v2 = v1 + TLS. v1 devices cannot
talk to v2 devices (they must be updated together).

## Discovery
Every device advertises an mDNS/DNS-SD service `_mirrox._tcp` on its TCP port (default `48500`).
TXT records: `id` (stable device id), `type` (`android` | `windows` | ...).
The service name is the device name.

## Transport: TLS
Every connection is TLS 1.2 or 1.3 on the same TCP port. Each device has one long-lived self-signed
ECDSA P-256 certificate (created on first start). There is no CA: devices **pin the SHA-256 fingerprint of the
peer certificate** (lowercase hex of the DER bytes).

The client connects, finishes the TLS handshake, and compares the server fingerprint **before sending anything**:
- fingerprint from the QR code (`fp`), if pairing by QR; otherwise
- the fingerprint saved for that device, if it was paired before; otherwise
- first PIN pairing without a QR: the fingerprint is accepted and saved (trust on first use).

A mismatch aborts the connection (`cert_changed`); the PIN and token are never sent. A saved fingerprint is only
replaced by scanning that device's QR code again (Windows: asks to forget the device).
Tokens are never sent to a server whose fingerprint is not pinned.

## Framing
Every message is a JSON object:

    [4 bytes big-endian length N][N bytes UTF-8 JSON]

`N` must be 1..65536. A `file` message is followed by exactly `size` raw bytes.

## Handshake
Client sends first:

    {"t":"hello","v":2,"id":"<device id>","name":"<name>","type":"android","code":"482731","token":"<hex>"}

`code` is the 6-digit PIN shown on the receiving device (Receive Screen / QR). `token` is the
long-lived token the receiver issued when we paired. Either one is enough.

Server replies:

    {"t":"ok","v":2,"id":"...","name":"...","type":"windows","token":"<hex>"}   // token only on first pairing
    {"t":"err","msg":"auth"}                                                      // then closes

After a successful PIN pairing the PIN is rotated. 5 wrong PINs also rotate it.

## Messages (after handshake)
| Message | Direction | Meaning |
|---|---|---|
| `{"t":"file","name":"a.mp4","size":123}` + `size` bytes | client -> server | send one file |
| `{"t":"file_ok","name":"a.mp4"}` | server -> client | file stored (name may be changed to avoid clashes) |
| `{"t":"err","msg":"..."}` | either | failure |
| `{"t":"bye"}` | client -> server | close |
| `{"t":"cast_start","codec":"h264","w":1080,"h":2400,"fps":30}` | client -> server | start a screen cast |
| `{"t":"cast_ok"}` | server -> client | cast accepted, video packets follow |

Cancel = close the socket. The receiver deletes the partial file.
Screen casting (phone -> PC) uses `cast_start`, see below.

## Screen cast
The receiver can be Windows (window) or Android (full-screen viewer); the sender is Android.
After the normal handshake the phone sends `cast_start` (`w`,`h` 16..8192, codec must be `h264`). The PC answers
`cast_ok` or `{"t":"err","msg":...}` with one of `unsupported_codec`, `bad_size`, `no_display`, `no_decoder`, `cast_busy`.
After `cast_ok` the connection carries only binary packets, phone -> PC:

    [1 byte type][4 bytes length][8 bytes presentation time in us][payload]      (all big-endian)

| Type | Name | Payload |
|---|---|---|
| 1 | CONFIG | u16 width, u16 height, SPS+PPS (Annex-B). Sent before every key frame; a new size means the phone rotated |
| 2 | KEY | one H.264 access unit starting with an IDR frame (Annex-B, no parameter sets) |
| 3 | DELTA | one H.264 access unit (P frame) |
| 4 / 5 | PAUSE / RESUME | none |
| 6 | END | none, the phone stopped on purpose |
| 7 | PING | none, sent every 2 s when idle (the PC drops a silent connection after 15 s) |

Payload max 16 MiB. Unknown types are ignored. Either side stops by closing the socket. If the network is slow the
phone drops frames up to the next key frame (key frame every 2 s) instead of building up delay.

## QR payload

    mirrox://pair?host=192.168.1.5&port=48500&code=482731&id=<device id>&name=DESKTOP-PC&fp=<64 hex>&v=2

`fp` is required; a QR code without it comes from an old version and is refused.

## Security notes
- Traffic is encrypted (TLS 1.2+). Eavesdropping on the Wi-Fi no longer reveals PINs, tokens or files.
- **QR pairing is fully authenticated**: the QR code carries the certificate fingerprint, so a man-in-the-middle
  on the Wi-Fi cannot impersonate the device. Prefer QR for the first pairing.
- **PIN-only pairing (typing the PIN) is trust on first use**: safe against passive listeners, but an attacker who
  actively sits in the middle during that very first pairing could impersonate the device. After pairing, the
  fingerprint is pinned and later connections are protected.
- PIN is 6 digits, one-time, rotated after each pairing and after 5 wrong tries; tokens are random 128-bit values.
- Upgrading from v1: all v1 tokens are revoked once (they were sent unencrypted); pair every device again.
- The private key is stored in the app's private storage (Android: SharedPreferences, backup disabled; Windows:
  `~/.mirrox/key.pem`). Deleting it creates a new identity, so other devices will show `cert_changed`.
