package com.mirrox.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import javax.net.ssl.SSLException
import javax.net.ssl.SSLServerSocket
import java.net.Socket
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.UUID

/** Wire format is documented in PROTOCOL.md (shared with the Windows companion). */
object Proto {
    const val PORT = 48500
    const val SERVICE = "_mirrox._tcp."
    const val MAX_HEADER = 64 * 1024
    const val MAX_FILE = 64L * 1024 * 1024 * 1024
    const val CHUNK = 64 * 1024
}

/** A device found on the network (or remembered from before). */
data class Peer(val id: String, val name: String, val type: String, val host: String, val port: Int, val svc: String = "")

data class Known(
    val id: String, val name: String, val type: String, val host: String, val port: Int,
    val issued: String?, val token: String?, val last: Long,
    /** SHA-256 fingerprint of the device's TLS certificate (pinned). */
    val fp: String? = null
) {
    /** True when we hold a token from this device, so we can connect without a PIN. */
    val canConnect get() = token != null
    fun toPeer() = Peer(id, name, type, host, port)
}

class Hist(val name: String, val detail: String, val sent: Boolean, val ok: Boolean)

class Xfer(val name: String, val total: Long, val sending: Boolean, val peer: String) {
    var done by mutableLongStateOf(0L)
    var speed by mutableLongStateOf(0L)
    @Volatile var cancelled = false
}

class Pairing(val host: String, val port: Int, val code: String, val id: String, val name: String, val fp: String? = null)

class NetError(val msg: String) : Exception(msg)

/** An accepted screen-cast connection: write video packets to [out] (see PROTOCOL.md). */
class CastLink(private val sock: Socket, val out: DataOutputStream) {
    fun close() { try { sock.close() } catch (_: IOException) {} }
}

fun typeLabel(t: String) = when (t) {
    "android" -> "Android"; "windows" -> "Windows"; "linux" -> "Linux"; "ios" -> "iOS"; "mac" -> "macOS"; else -> "Device"
}

fun errText(e: Throwable) = when ((e as? NetError)?.msg) {
    "auth" -> "Wrong PIN. Check the code on the other device."
    "pin_required" -> "Enter the PIN shown on the other device."
    "cancelled" -> "Cancelled."
    "unsupported", "unsupported_codec" -> "That device can't show your screen yet. Update Mirrox on it."
    "no_decoder" -> "That PC can't play video yet. Update Mirrox for Windows."
    "no_display" -> "That device isn't set up to show a screen."
    "cast_busy" -> "That device is already showing another screen."
    "bad_size" -> "That device refused this screen size."
    "busy" -> "Another transfer is already running."
    "cert_changed" -> "This device's security identity changed (for example after reinstalling Mirrox). If you trust it, scan its QR code to pair again."
    else -> if (e is SSLException) "Secure connection failed. Make sure both devices run the latest Mirrox." else if (e is IOException) "Could not reach the device. Check that both are on the same Wi-Fi." else (e.message ?: "Something went wrong.")
}

class Net(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("mirrox", Context.MODE_PRIVATE)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val rnd = SecureRandom()
    private val tls = Tls.loadOrCreate(prefs)
    private val lock = Any()
    private val kmap = LinkedHashMap<String, Known>()

    val id: String = prefs.getString("id", null)
        ?: UUID.randomUUID().toString().replace("-", "").also { prefs.edit().putString("id", it).apply() }

    var name by mutableStateOf(prefs.getString("name", null) ?: (Build.MODEL ?: "Android"))
        private set
    var code by mutableStateOf(newCode())
        private set
    var port by mutableIntStateOf(Proto.PORT)
        private set
    var peers by mutableStateOf<List<Peer>>(emptyList())
        private set
    var known by mutableStateOf<List<Known>>(emptyList())
        private set
    var current by mutableStateOf<Xfer?>(null)
        private set
    var history by mutableStateOf<List<Hist>>(emptyList())
        private set

    /** Fingerprint of our TLS certificate (shown to other devices via the QR code). */
    val fingerprint: String get() = tls.fp

    val saveLocation: String
        get() = if (Build.VERSION.SDK_INT >= 29) "Downloads/Mirrox" else "Android/data/${ctx.packageName}/files/Download/Mirrox"

    private var fails = 0
    private var server: ServerSocket? = null
    private var regL: NsdManager.RegistrationListener? = null
    private var discL: NsdManager.DiscoveryListener? = null
    private val nsd get() = ctx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val rq = ArrayDeque<NsdServiceInfo>()
    private var resolving = false

    init { load() }

    // ------------------------------------------------------------ lifecycle
    fun start() {
        if (server != null) return
        val ss = Tls.serverFactory(tls).createServerSocket()
        ss.reuseAddress = true
        (ss as? SSLServerSocket)?.let { it.enabledProtocols = Tls.protocols(it.supportedProtocols) }
        try { ss.bind(InetSocketAddress(Proto.PORT)) } catch (e: IOException) { ss.bind(InetSocketAddress(0)) }
        server = ss
        port = ss.localPort
        scope.launch {
            while (isActive) {
                val s = try { ss.accept() } catch (e: IOException) { break }
                launch { handle(s) }
            }
        }
        register()
        discover()
    }

    fun stop() {
        try { regL?.let { nsd.unregisterService(it) } } catch (_: Exception) {}
        try { discL?.let { nsd.stopServiceDiscovery(it) } } catch (_: Exception) {}
        regL = null; discL = null
        try { server?.close() } catch (_: IOException) {}
        server = null
        scope.cancel()
    }

    fun rename(n: String) {
        name = n.trim().take(40).ifEmpty { name }
        prefs.edit().putString("name", name).apply()
        try { regL?.let { nsd.unregisterService(it) } } catch (_: Exception) {}
        register()
    }

    fun cancel() { current?.cancelled = true }

    // ------------------------------------------------------------ pairing / QR
    fun canConnect(p: Peer) = synchronized(lock) { kmap[p.id]?.canConnect == true }

    fun qrPayload(): String {
        fun e(s: String) = URLEncoder.encode(s, "UTF-8")
        return "mirrox://pair?host=${e(localIp() ?: "0.0.0.0")}&port=$port&code=$code&id=$id&name=${e(name)}&fp=$fingerprint&v=2"
    }

    fun parseQr(text: String): Pairing? = try {
        val u = Uri.parse(text.trim())
        val code = u.getQueryParameter("code")
        val host = u.getQueryParameter("host")
        val fp = u.getQueryParameter("fp")?.lowercase()
        // A QR code without a certificate fingerprint comes from an old (unencrypted) Mirrox: refuse it.
        if (u.scheme != "mirrox" || u.host != "pair" || code.isNullOrEmpty() || host.isNullOrEmpty() || fp == null || !Regex("[0-9a-f]{64}").matches(fp)) null
        else Pairing(host, u.getQueryParameter("port")?.toIntOrNull() ?: Proto.PORT, code, u.getQueryParameter("id") ?: "", u.getQueryParameter("name") ?: host, fp)
    } catch (e: Exception) { null }

    /** Pair with a device using its PIN. Result is the device on success. */
    fun pair(host: String, port: Int, pin: String, id: String?, fp: String? = null, done: (Result<Peer>) -> Unit) {
        scope.launch {
            val r = runCatching {
                val s = connectTo(host, port, id, pin, fp)
                val rid = s.reply.optString("id")
                s.close()
                Peer(rid, s.reply.optString("name", host), s.reply.optString("type", "unknown"), host, port)
            }
            withContext(Dispatchers.Main) { done(r) }
        }
    }

    fun pairQr(p: Pairing, done: (Result<Peer>) -> Unit) = pair(p.host, p.port, p.code, p.id.ifEmpty { null }, p.fp, done)

    /** Test that a trusted device still accepts our token (used before casting). */
    fun verify(p: Peer, done: (Result<Peer>) -> Unit) {
        scope.launch {
            val r = runCatching { connectTo(p.host, p.port, p.id, null).close(); p }
            withContext(Dispatchers.Main) { done(r) }
        }
    }

    /**
     * Opens a secure connection to [p] and asks it to show our screen ([w] x [h] H.264). Returns once the other
     * device has said yes. Blocking: call from a background thread.
     */
    fun openCast(p: Peer, w: Int, h: Int, fps: Int): CastLink {
        val s = connectTo(p.host, p.port, p.id, null)
        try {
            s.sock.soTimeout = 10_000
            sendMsg(s.out, JSONObject().put("t", "cast_start").put("codec", "h264").put("w", w).put("h", h).put("fps", fps))
            val r = readMsg(s.inp)
            if (r.optString("t") != "cast_ok") throw NetError(r.optString("msg", "failed"))
            s.sock.soTimeout = 0          // video can pause for a long time; the sender sends keep-alives
            s.sock.tcpNoDelay = true
            s.sock.keepAlive = true
            return CastLink(s.sock, s.out)
        } catch (e: Exception) {
            try { s.sock.close() } catch (_: IOException) {}
            throw e
        }
    }

    // ------------------------------------------------------------ files
    /** Name and size of a picked file, or null if the size can't be determined. */
    fun describe(uri: Uri): Pair<String, Long>? {
        var n = "file"; var sz = -1L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val j = c.getColumnIndex(OpenableColumns.SIZE)
                if (i >= 0) c.getString(i)?.let { n = it }
                if (j >= 0 && !c.isNull(j)) sz = c.getLong(j)
            }
        }
        if (sz < 0) sz = try { ctx.contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L } catch (e: Exception) { -1L }
        return if (sz < 0) null else n to sz
    }

    fun sendFile(p: Peer, uri: Uri, fileName: String, size: Long, pin: String?, done: (Result<String>) -> Unit) {
        scope.launch {
            val r = runCatching { doSend(p, uri, fileName, size, pin) }
            withContext(Dispatchers.Main) { done(r) }
        }
    }

    private fun doSend(p: Peer, uri: Uri, fileName: String, size: Long, pin: String?): String {
        if (current != null) throw NetError("busy")
        val x = Xfer(fileName, size, true, p.name)
        current = x
        var sess: Session? = null
        try {
            val s = connectTo(p.host, p.port, p.id, pin)
            sess = s
            sendMsg(s.out, JSONObject().put("t", "file").put("name", fileName).put("size", size))
            val ins = ctx.contentResolver.openInputStream(uri) ?: throw IOException("cannot read file")
            ins.use {
                val buf = ByteArray(Proto.CHUNK)
                var left = size
                var last = System.nanoTime(); var lastDone = 0L
                while (left > 0) {
                    val n = it.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) throw IOException("file ended early")
                    if (x.cancelled) throw NetError("cancelled")
                    s.out.write(buf, 0, n)
                    left -= n
                    x.done += n
                    val now = System.nanoTime()
                    if (now - last >= 250_000_000L) { x.speed = ((x.done - lastDone) * 1_000_000_000L / (now - last)); last = now; lastDone = x.done }
                }
            }
            s.out.flush()
            val resp = readMsg(s.inp)
            if (resp.optString("t") != "file_ok") throw NetError(resp.optString("msg", "failed"))
            history = listOf(Hist(fileName, "To ${p.name} • ${fmt(size)}", true, true)) + history
            return resp.optString("name", fileName)
        } catch (e: Exception) {
            val why = if ((e as? NetError)?.msg == "cancelled") "Cancelled" else "Failed"
            history = listOf(Hist(fileName, "To ${p.name} • $why", true, false)) + history
            throw e
        } finally {
            current = null
            sess?.close()
        }
    }

    // ------------------------------------------------------------ server side
    private fun handle(s: Socket) {
        try {
            s.soTimeout = 30_000
            val inp = DataInputStream(s.getInputStream().buffered())
            val out = DataOutputStream(s.getOutputStream().buffered())
            val from = auth(readMsg(inp), out, s) ?: return
            while (true) {
                val m = readMsg(inp)
                when (m.optString("t")) {
                    "file" -> receive(m, inp, out, from)
                    "bye" -> return
                    else -> sendMsg(out, JSONObject().put("t", "err").put("msg", "unsupported"))
                }
            }
        } catch (_: Exception) {
        } finally {
            try { s.close() } catch (_: IOException) {}
        }
    }

    private fun auth(h: JSONObject, out: DataOutputStream, s: Socket): String? {
        val pid = h.optString("id"); val tok = h.optString("token"); val pin = h.optString("code")
        if (h.optString("t") != "hello" || h.optInt("v") != 2 || pid.isEmpty() || pid.length > 64) {
            sendMsg(out, JSONObject().put("t", "err").put("msg", "bad_hello")); return null
        }
        val nm = h.optString("name").take(64).ifEmpty { "Unknown" }
        val typ = h.optString("type", "unknown").ifEmpty { "unknown" }
        var newToken: String? = null
        val ok = synchronized(lock) {
            val issued = kmap[pid]?.issued
            when {
                tok.isNotEmpty() && issued != null && same(tok, issued) -> true
                pin.isNotEmpty() -> {
                    if (same(pin, code)) { newToken = randomHex(16); true }
                    else { fails++; if (fails >= 5) rotate(); false }
                }
                else -> false
            }
        }
        if (!ok) { sendMsg(out, JSONObject().put("t", "err").put("msg", "auth")); return null }
        remember(pid, name = nm, type = typ, host = s.inetAddress?.hostAddress, issued = newToken)
        if (newToken != null) synchronized(lock) { rotate() }
        val reply = JSONObject().put("t", "ok").put("v", 2).put("id", id).put("name", name).put("type", "android")
        newToken?.let { reply.put("token", it) }
        sendMsg(out, reply)
        return nm
    }

    private fun receive(m: JSONObject, inp: DataInputStream, out: DataOutputStream, from: String) {
        val size = m.optLong("size", -1)
        if (size < 0 || size > Proto.MAX_FILE) {
            sendMsg(out, JSONObject().put("t", "err").put("msg", "bad_size")); throw IOException("bad size")
        }
        if (current != null) { sendMsg(out, JSONObject().put("t", "err").put("msg", "busy")); throw NetError("busy") }
        val wanted = safeName(m.optString("name"))
        val x = Xfer(wanted, size, false, from)
        current = x
        var sink: Sink? = null
        try {
            sink = openSink(wanted)
            val buf = ByteArray(Proto.CHUNK)
            var left = size
            var last = System.nanoTime(); var lastDone = 0L
            while (left > 0) {
                val n = inp.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                if (n < 0) throw IOException("connection closed")
                if (x.cancelled) throw NetError("cancelled")
                sink.out.write(buf, 0, n)
                left -= n
                x.done += n
                val now = System.nanoTime()
                if (now - last >= 250_000_000L) { x.speed = ((x.done - lastDone) * 1_000_000_000L / (now - last)); last = now; lastDone = x.done }
            }
            sink.commit()
            sendMsg(out, JSONObject().put("t", "file_ok").put("name", sink.name))
            history = listOf(Hist(sink.name, "From $from • ${fmt(size)}", false, true)) + history
        } catch (e: Exception) {
            sink?.abort()
            val why = if ((e as? NetError)?.msg == "cancelled") "Cancelled" else "Failed"
            history = listOf(Hist(wanted, "From $from • $why", false, false)) + history
            throw e
        } finally {
            if (current === x) current = null
        }
    }

    private class Sink(val name: String, val out: OutputStream, val commit: () -> Unit, val abort: () -> Unit)

    private fun openSink(name: String): Sink {
        if (Build.VERSION.SDK_INT >= 29) {
            val ext = name.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Mirrox")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val res = ctx.contentResolver
            val uri = res.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw IOException("cannot create file")
            val os = res.openOutputStream(uri) ?: throw IOException("cannot create file")
            var finalName = name
            res.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0)?.let { finalName = it }
            }
            return Sink(finalName, os,
                {
                    os.close()
                    res.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                },
                {
                    try { os.close() } catch (_: IOException) {}
                    res.delete(uri, null, null)
                })
        }
        val dir = File(ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir, "Mirrox").apply { mkdirs() }
        val base = name.substringBeforeLast('.', name)
        val ext = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        var f = File(dir, name); var i = 1
        while (f.exists()) { f = File(dir, "$base ($i)$ext"); i++ }
        val tmp = File(dir, f.name + ".part")
        val os = FileOutputStream(tmp)
        return Sink(f.name, os, { os.close(); tmp.renameTo(f) }, { try { os.close() } catch (_: IOException) {}; tmp.delete() })
    }

    // ------------------------------------------------------------ client side
    private class Session(val sock: Socket, val inp: DataInputStream, val out: DataOutputStream, val reply: JSONObject) {
        fun close() {
            try { sendMsg(out, JSONObject().put("t", "bye")) } catch (_: Exception) {}
            try { sock.close() } catch (_: IOException) {}
        }
    }

    /**
     * Opens a TLS session. The certificate must match a pinned fingerprint: [fp] (from a QR code) or the one
     * saved for [peerId]. With neither (first PIN pairing) the fingerprint is learned and pinned on success.
     */
    private fun connectTo(host: String, port: Int, peerId: String?, pin: String?, fp: String? = null): Session {
        val known = peerId?.let { synchronized(lock) { kmap[it] } }
        val pinned = (fp ?: known?.fp)?.lowercase()
        val sock = Tls.connect(host, port, 8000)
        try {
            val seen = Tls.peerFingerprint(sock)
            if (pinned != null && !same(seen, pinned)) throw NetError("cert_changed")
            val inp = DataInputStream(sock.getInputStream().buffered())
            val out = DataOutputStream(sock.getOutputStream().buffered())
            val h = JSONObject().put("t", "hello").put("v", 2).put("id", id).put("name", name).put("type", "android")
            // Never send a token to a server whose certificate we have not pinned.
            val tok = if (pinned != null) known?.token else null
            if (!tok.isNullOrEmpty()) h.put("token", tok)
            if (!pin.isNullOrEmpty()) h.put("code", pin)
            if (!h.has("token") && !h.has("code")) throw NetError("pin_required")
            sendMsg(out, h)
            val reply = readMsg(inp)
            if (reply.optString("t") != "ok") throw NetError(reply.optString("msg", "failed"))
            val rid = reply.optString("id")
            if (rid.isNotEmpty()) remember(
                rid, name = reply.optString("name").ifEmpty { null }, type = reply.optString("type").ifEmpty { null },
                host = host, port = port, token = reply.optString("token").ifEmpty { null }, fp = seen
            )
            return Session(sock, inp, out, reply)
        } catch (e: Exception) {
            try { sock.close() } catch (_: IOException) {}
            throw e
        }
    }

    // ------------------------------------------------------------ discovery (NSD)
    private fun register() {
        val info = NsdServiceInfo().apply {
            serviceName = this@Net.name
            serviceType = Proto.SERVICE
            port = this@Net.port
            setAttribute("id", this@Net.id)
            setAttribute("type", "android")
        }
        val l = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {}
            override fun onRegistrationFailed(i: NsdServiceInfo, e: Int) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, e: Int) {}
        }
        regL = l
        try { nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l) } catch (_: Exception) {}
    }

    private fun discover() {
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(t: String) {}
            override fun onServiceFound(i: NsdServiceInfo) {
                if (i.serviceType.contains("_mirrox")) { synchronized(rq) { rq.addLast(i) }; pump() }
            }
            override fun onServiceLost(i: NsdServiceInfo) { peers = peers.filterNot { it.svc == i.serviceName } }
            override fun onDiscoveryStopped(t: String) {}
            override fun onStartDiscoveryFailed(t: String, e: Int) {}
            override fun onStopDiscoveryFailed(t: String, e: Int) {}
        }
        discL = l
        try { nsd.discoverServices(Proto.SERVICE, NsdManager.PROTOCOL_DNS_SD, l) } catch (_: Exception) {}
    }

    // NSD can resolve only one service at a time, so resolves are queued.
    private fun pump() {
        val next = synchronized(rq) {
            if (resolving || rq.isEmpty()) null else { resolving = true; rq.removeFirst() }
        } ?: return
        try {
            nsd.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, e: Int) { resolved() }
                override fun onServiceResolved(i: NsdServiceInfo) { try { addPeer(i) } finally { resolved() } }
            })
        } catch (_: Exception) { resolved() }
    }

    private fun resolved() { synchronized(rq) { resolving = false }; pump() }

    private fun addPeer(i: NsdServiceInfo) {
        val pid = i.attributes["id"]?.toString(Charsets.UTF_8) ?: return
        if (pid.isEmpty() || pid == id) return
        val host = i.host?.hostAddress ?: return
        val p = Peer(pid, i.serviceName, i.attributes["type"]?.toString(Charsets.UTF_8) ?: "unknown", host, i.port, i.serviceName)
        peers = peers.filterNot { it.id == pid } + p
    }

    // ------------------------------------------------------------ helpers
    private fun rotate() { fails = 0; code = newCode() }
    private fun newCode() = "%06d".format(rnd.nextInt(1_000_000))
    private fun randomHex(bytes: Int) = ByteArray(bytes).also { rnd.nextBytes(it) }.joinToString("") { "%02x".format(it) }

    private fun remember(pid: String, name: String? = null, type: String? = null, host: String? = null, port: Int? = null, issued: String? = null, token: String? = null, fp: String? = null) {
        synchronized(lock) {
            val o = kmap[pid]
            kmap[pid] = Known(
                pid, name ?: o?.name ?: "Unknown", type ?: o?.type ?: "unknown", host ?: o?.host ?: "",
                port ?: o?.port ?: Proto.PORT, issued ?: o?.issued, token ?: o?.token, System.currentTimeMillis(), fp ?: o?.fp
            )
            known = kmap.values.sortedByDescending { it.last }
            val j = JSONObject()
            kmap.values.forEach { k ->
                j.put(k.id, JSONObject().put("name", k.name).put("type", k.type).put("host", k.host).put("port", k.port)
                    .put("issued", k.issued ?: "").put("token", k.token ?: "").put("last", k.last).put("fp", k.fp ?: ""))
            }
            prefs.edit().putString("known", j.toString()).apply()
        }
    }

    private fun load() {
        // v1 tokens were sent unencrypted: revoke them once (devices must pair again).
        val legacy = prefs.getInt("proto", 1) < 2
        prefs.edit().putInt("proto", 2).apply()
        try {
            val o = JSONObject(prefs.getString("known", null) ?: return)
            o.keys().forEach { k ->
                val j = o.getJSONObject(k)
                kmap[k] = Known(
                    k, j.optString("name", "Unknown"), j.optString("type", "unknown"), j.optString("host"),
                    j.optInt("port", Proto.PORT),
                    if (legacy) null else j.optString("issued").ifEmpty { null },
                    if (legacy) null else j.optString("token").ifEmpty { null },
                    j.optLong("last"), j.optString("fp").ifEmpty { null }
                )
            }
            known = kmap.values.sortedByDescending { it.last }
        } catch (_: Exception) {}
    }

    companion object {
        fun sendMsg(out: DataOutputStream, o: JSONObject) {
            val b = o.toString().toByteArray(Charsets.UTF_8)
            out.writeInt(b.size); out.write(b); out.flush()
        }

        fun readMsg(inp: DataInputStream): JSONObject {
            val n = inp.readInt()
            if (n < 1 || n > Proto.MAX_HEADER) throw IOException("bad header")
            val b = ByteArray(n)
            inp.readFully(b)
            return JSONObject(String(b, Charsets.UTF_8))
        }

        fun same(a: String, b: String) = MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))

        fun safeName(raw: String): String {
            var n = raw.replace('\\', '/').substringAfterLast('/')
            n = n.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001f]"), "_").trim(' ', '.')
            if (n.isEmpty()) n = "file"
            if (Regex("^(con|prn|aux|nul|com\\d|lpt\\d)(\\..*)?$", RegexOption.IGNORE_CASE).matches(n)) n = "_$n"
            return n.take(200)
        }

        fun localIp(): String? = try {
            NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback }
                .sortedBy { if (it.name.startsWith("wlan")) 0 else 1 }
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { it is Inet4Address && it.isSiteLocalAddress }?.hostAddress
        } catch (e: Exception) { null }
    }
}
