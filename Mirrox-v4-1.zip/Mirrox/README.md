# Mirrox

Android app + Windows companion. Pair with a PIN or QR code, then send files and cast the phone screen to the PC on the same Wi-Fi.
Wire format: see [PROTOCOL.md](PROTOCOL.md).

## Build (GitHub Actions)
1. Is folder ko GitHub repo me upload karo (branch: `main`).
2. Actions tab -> "Build" -> Run workflow (ya push par apne aap chalega).
3. Artifacts:
   - `Mirrox-debug-apk` -> `app-debug.apk` (Android)
   - `MirroxPC-windows` -> `MirroxPC.exe` (Windows)

## Windows (bina exe ke)
    cd windows
    pip install -r requirements.txt
    python mirrox_pc.py              # window: QR + PIN dikhta hai
    python mirrox_pc.py --headless   # sirf receive
    python mirrox_pc.py send 192.168.1.5 photo.jpg --code 482731
    python -m unittest discover     # protocol + cast tests

## Kaise use karein
- **PC -> Phone:** phone par Receive Screen kholo. PC app me phone select karo, Send File, phone ka PIN daalo (pehli baar).
- **Screen cast (phone -> PC):** PC app khula rakho. Phone par Cast Screen -> PC chuno -> Start now -> Android ka permission dialog Allow karo. PC par window khulti hai (F11 / double-click = fullscreen, window band = cast band). Pause/Stop phone par ya notification se.
- **Phone -> PC:** phone par Send Files -> file chuno -> device chuno. PC ka PIN (ya QR scan) pehli baar chahiye. Uske baad PIN nahi lagta.
- PC nahi dikh raha ho to Enter PIN me PC ka address (jaise `192.168.1.5`) aur PIN daalo.
- Received files Android par `Downloads/Mirrox` me aati hain.

## Abhi kya asli hai, kya nahi
Asli: device discovery (mDNS), PIN/QR pairing, trusted devices, file send/receive (Android <-> Windows), cancel,
**TLS encryption** (har device ka certificate, fingerprint pin).
**Screen cast** (phone -> PC, H.264 TLS pe, rotation, pause).
Abhi nahi: audio, PC -> phone screen, background me file receive karna (app khula hona chahiye).
PC par video decode ke liye `av` (PyAV, exe me bundled) chahiye; na ho to PATH me `ffmpeg` fallback hai.

## Security (v2: TLS)
- Poora traffic TLS se encrypted hai. Har device ka apna certificate hota hai, aur uska fingerprint pin hota hai.
- **Pehli baar QR se pair karo** (best): QR me fingerprint hota hai, isliye Wi-Fi par beech me koi nakli device nahi ban sakta.
- Sirf PIN type karke pehli pairing "trust on first use" hai: chhup ke sunne walon se safe, lekin pehli pairing ke waqt
  active attacker beech me ho to risk rehta hai. Uske baad fingerprint pin ho jata hai.
- v1 se update karne par purane tokens revoke ho jate hain: dono taraf ek baar dobara pair karo.
- "Security identity changed" aaye to: reinstall ke baad normal hai (QR se dobara pair karo). Windows par poochega ki device forget karna hai ya nahi.
- Windows ko `cryptography` chahiye (`pip install -r requirements.txt`).
